// Configuration de la scène Three.js
const canvas = document.getElementById('canvas3d');
const scene = new THREE.Scene();
scene.background = new THREE.Color(0xf0f0f0);

// Caméra - Vue de face
const camera = new THREE.PerspectiveCamera(75, 800 / 750, 0.1, 1000);
camera.position.set(0, 3, 12);
camera.lookAt(0, 0, 0);

// Renderer
const renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true });
renderer.setSize(800, 750);
renderer.shadowMap.enabled = true;

// Lumières
const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
scene.add(ambientLight);

const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
directionalLight.position.set(5, 10, 5);
directionalLight.castShadow = true;
scene.add(directionalLight);

// Contrôles de la caméra désactivés
// const controls = new THREE.OrbitControls(camera, renderer.domElement);
// controls.enableDamping = true;
// controls.dampingFactor = 0.05;
// controls.minDistance = 3;
// controls.maxDistance = 10;

// Création d'un T-Rex simplifié en géométrie
const trexGroup = new THREE.Group();

// Corps
const bodyGeometry = new THREE.BoxGeometry(2, 1.5, 1);
const bodyMaterial = new THREE.MeshPhongMaterial({ color: 0x4a7c59 });
const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
body.position.y = 2;
body.castShadow = true;
trexGroup.add(body);

// Tête
const headGeometry = new THREE.BoxGeometry(1.2, 1, 0.8);
const head = new THREE.Mesh(headGeometry, bodyMaterial);
head.position.set(1.3, 2.5, 0);
head.castShadow = true;
trexGroup.add(head);

// Mâchoire
const jawGeometry = new THREE.BoxGeometry(0.8, 0.4, 0.6);
const jawMaterial = new THREE.MeshPhongMaterial({ color: 0x3d6647 });
const jaw = new THREE.Mesh(jawGeometry, jawMaterial);
jaw.position.set(1.7, 2.2, 0);
jaw.castShadow = true;
trexGroup.add(jaw);

// Yeux
const eyeGeometry = new THREE.SphereGeometry(0.1, 8, 8);
const eyeMaterial = new THREE.MeshPhongMaterial({ color: 0xffff00 });
const eyeLeft = new THREE.Mesh(eyeGeometry, eyeMaterial);
eyeLeft.position.set(1.7, 2.7, 0.3);
trexGroup.add(eyeLeft);
const eyeRight = new THREE.Mesh(eyeGeometry, eyeMaterial);
eyeRight.position.set(1.7, 2.7, -0.3);
trexGroup.add(eyeRight);

// Queue
const tailGeometry = new THREE.ConeGeometry(0.4, 2.5, 8);
const tail = new THREE.Mesh(tailGeometry, bodyMaterial);
tail.rotation.z = Math.PI / 2;
tail.position.set(-2, 2, 0);
tail.castShadow = true;
trexGroup.add(tail);

// Jambes
const legGeometry = new THREE.CylinderGeometry(0.2, 0.25, 1.5, 8);
const legLeft = new THREE.Mesh(legGeometry, bodyMaterial);
legLeft.position.set(0.5, 0.75, 0.4);
legLeft.castShadow = true;
trexGroup.add(legLeft);

const legRight = new THREE.Mesh(legGeometry, bodyMaterial);
legRight.position.set(0.5, 0.75, -0.4);
legRight.castShadow = true;
trexGroup.add(legRight);

// Pieds
const footGeometry = new THREE.BoxGeometry(0.6, 0.2, 0.4);
const footLeft = new THREE.Mesh(footGeometry, bodyMaterial);
footLeft.position.set(0.7, 0.1, 0.4);
footLeft.castShadow = true;
trexGroup.add(footLeft);

const footRight = new THREE.Mesh(footGeometry, bodyMaterial);
footRight.position.set(0.7, 0.1, -0.4);
footRight.castShadow = true;
trexGroup.add(footRight);

// Petits bras
const armGeometry = new THREE.CylinderGeometry(0.1, 0.08, 0.6, 8);
const armLeft = new THREE.Mesh(armGeometry, bodyMaterial);
armLeft.position.set(0.8, 2.3, 0.5);
armLeft.rotation.z = 0.5;
trexGroup.add(armLeft);

const armRight = new THREE.Mesh(armGeometry, bodyMaterial);
armRight.position.set(0.8, 2.3, -0.5);
armRight.rotation.z = 0.5;
trexGroup.add(armRight);

// Grille de positionnement pour 9 dinosaures (3 lignes superposées)
const spacingX = 5; // Espacement horizontal
const spacingY = 5; // Espacement vertical

const positions = [
    // Ligne du haut
    [-spacingX, spacingY -2, 0],   // Position 0
    [0, spacingY -2, 0],           // Position 1
    [spacingX, spacingY -2, 0],    // Position 2
    
    // Ligne du milieu
    [-spacingX, 0 -2, 0],           // Position 3
    [0, 0 -2, 0],                   // Position 4
    [spacingX, 0 -2, 0],            // Position 5
    
    // Ligne du bas
    [-spacingX, -spacingY -2, 0],    // Position 6
    [0, -spacingY -2, 0],            // Position 7
    [spacingX, -spacingY -2, 0]      // Position 8
];

trexGroup.rotation.y = 5*Math.PI / 4;
trexGroup.scale.set(0.6, 0.6, 0.6); // Réduction à 60%
// Position du T-Rex (Position 0: Haut-Gauche)
trexGroup.position.set(positions[0][0], positions[0][1], positions[0][2]);

scene.add(trexGroup);

// === TRICÉRATOPS ===
const triceratopsGroup = new THREE.Group();

// Corps
const triceraBody = new THREE.BoxGeometry(2.2, 1.3, 1.2);
const triceraBodyMaterial = new THREE.MeshPhongMaterial({ color: 0x8b6f47 });
const triceraBodyMesh = new THREE.Mesh(triceraBody, triceraBodyMaterial);
triceraBodyMesh.position.y = 1.8;
triceraBodyMesh.castShadow = true;
triceratopsGroup.add(triceraBodyMesh);

// Tête avec collerette
const headGeom = new THREE.BoxGeometry(1, 0.9, 0.9);
const triceraHead = new THREE.Mesh(headGeom, triceraBodyMaterial);
triceraHead.position.set(1.5, 1.8, 0);
triceraHead.castShadow = true;
triceratopsGroup.add(triceraHead);

// Collerette (large disque derrière la tête)
const collerette = new THREE.CylinderGeometry(1.2, 1.2, 0.2, 16);
const colleretteMaterial = new THREE.MeshPhongMaterial({ color: 0xa0826d });
const colleretteMesh = new THREE.Mesh(collerette, colleretteMaterial);
colleretteMesh.rotation.z = Math.PI / 2;
colleretteMesh.position.set(0.8, 2.2, 0);
colleretteMesh.castShadow = true;
triceratopsGroup.add(colleretteMesh);

// Museau/bec
const beakGeom = new THREE.ConeGeometry(0.3, 0.5, 8);
const beakMaterial = new THREE.MeshPhongMaterial({ color: 0x6b5d4f });
const beak = new THREE.Mesh(beakGeom, beakMaterial);
beak.rotation.z = -Math.PI / 2;
beak.position.set(2, 1.7, 0);
triceratopsGroup.add(beak);

// Cornes (3 cornes caractéristiques)
const hornGeom = new THREE.ConeGeometry(0.12, 0.8, 8);
const hornMaterial = new THREE.MeshPhongMaterial({ color: 0xf5deb3 });

// Corne du nez
const noseHorn = new THREE.Mesh(hornGeom, hornMaterial);
noseHorn.rotation.z = -Math.PI / 2;
noseHorn.position.set(1.9, 1.9, 0);
triceratopsGroup.add(noseHorn);

// Corne gauche
const leftHorn = new THREE.Mesh(hornGeom, hornMaterial);
leftHorn.rotation.z = -Math.PI / 2.5;
leftHorn.rotation.y = 0.3;
leftHorn.position.set(1.4, 2.3, 0.5);
triceratopsGroup.add(leftHorn);

// Corne droite
const rightHorn = new THREE.Mesh(hornGeom, hornMaterial);
rightHorn.rotation.z = -Math.PI / 2.5;
rightHorn.rotation.y = -0.3;
rightHorn.position.set(1.4, 2.3, -0.5);
triceratopsGroup.add(rightHorn);

// Yeux
const triceraEyeGeom = new THREE.SphereGeometry(0.1, 8, 8);
const triceraEyeMat = new THREE.MeshPhongMaterial({ color: 0x000000 });
const triceraEyeLeft = new THREE.Mesh(triceraEyeGeom, triceraEyeMat);
triceraEyeLeft.position.set(1.6, 2.1, 0.4);
triceratopsGroup.add(triceraEyeLeft);
const triceraEyeRight = new THREE.Mesh(triceraEyeGeom, triceraEyeMat);
triceraEyeRight.position.set(1.6, 2.1, -0.4);
triceratopsGroup.add(triceraEyeRight);

// Queue courte
const triceraQueue = new THREE.ConeGeometry(0.3, 1, 8);
const triceraQueueMesh = new THREE.Mesh(triceraQueue, triceraBodyMaterial);
triceraQueueMesh.rotation.z = Math.PI / 2;
triceraQueueMesh.position.set(-1.5, 1.6, 0);
triceraQueueMesh.castShadow = true;
triceratopsGroup.add(triceraQueueMesh);

// 4 Jambes robustes
const triceraLegGeom = new THREE.CylinderGeometry(0.25, 0.28, 1.3, 8);

const legFL = new THREE.Mesh(triceraLegGeom, triceraBodyMaterial);
legFL.position.set(0.8, 0.65, 0.5);
legFL.castShadow = true;
triceratopsGroup.add(legFL);

const legFR = new THREE.Mesh(triceraLegGeom, triceraBodyMaterial);
legFR.position.set(0.8, 0.65, -0.5);
legFR.castShadow = true;
triceratopsGroup.add(legFR);

const legBL = new THREE.Mesh(triceraLegGeom, triceraBodyMaterial);
legBL.position.set(-0.5, 0.65, 0.5);
legBL.castShadow = true;
triceratopsGroup.add(legBL);

const legBR = new THREE.Mesh(triceraLegGeom, triceraBodyMaterial);
legBR.position.set(-0.5, 0.65, -0.5);
legBR.castShadow = true;
triceratopsGroup.add(legBR);

// Rotation et position du Tricératops (Position 1: Haut-Centre)
triceratopsGroup.rotation.y = 5*Math.PI / 4;
triceratopsGroup.scale.set(0.6, 0.6, 0.6); // Réduction à 60%
triceratopsGroup.position.set(positions[1][0], positions[1][1], positions[1][2]);

scene.add(triceratopsGroup);

// === STÉGOSAURE (Version détaillée) ===
const stegosaurusGroup = new THREE.Group();

// Corps principal (ellipsoïde aplati)
const stegoBodyGeom = new THREE.SphereGeometry(1, 16, 16);
const stegoBodyMat = new THREE.MeshPhongMaterial({ color: 0xef6c00 });
const stegoBody = new THREE.Mesh(stegoBodyGeom, stegoBodyMat);
stegoBody.scale.set(1.3, 0.7, 0.6);
stegoBody.position.y = 1.3;
stegoBody.castShadow = true;
stegosaurusGroup.add(stegoBody);

// Cou
const stegoNeckGeom = new THREE.CylinderGeometry(0.25, 0.3, 0.6, 12);
const stegoNeck = new THREE.Mesh(stegoNeckGeom, stegoBodyMat);
stegoNeck.position.set(1.2, 1.2, 0);
stegoNeck.rotation.z = -Math.PI / 8;
stegoNeck.castShadow = true;
stegosaurusGroup.add(stegoNeck);

// Tête (petite et allongée)
const stegoHeadGeom = new THREE.BoxGeometry(0.5, 0.4, 0.35);
const stegoHead = new THREE.Mesh(stegoHeadGeom, stegoBodyMat);
stegoHead.position.set(1.65, 1.1, 0);
stegoHead.castShadow = true;
stegosaurusGroup.add(stegoHead);

// Museau pointu
const stegoSnoutGeom = new THREE.ConeGeometry(0.15, 0.3, 8);
const stegoSnout = new THREE.Mesh(stegoSnoutGeom, stegoBodyMat);
stegoSnout.rotation.z = -Math.PI / 2;
stegoSnout.position.set(1.85, 1.05, 0);
stegosaurusGroup.add(stegoSnout);

// Yeux
const stegoEyeGeom = new THREE.SphereGeometry(0.08, 12, 12);
const stegoEyeMat = new THREE.MeshPhongMaterial({ color: 0xffff00 });
const stegoEyeLeft = new THREE.Mesh(stegoEyeGeom, stegoEyeMat);
stegoEyeLeft.position.set(1.75, 1.2, 0.2);
stegosaurusGroup.add(stegoEyeLeft);
const stegoEyeRight = new THREE.Mesh(stegoEyeGeom, stegoEyeMat);
stegoEyeRight.position.set(1.75, 1.2, -0.2);
stegosaurusGroup.add(stegoEyeRight);

// Plaques dorsales (forme de losange améliorée)
const stegoPlateShape = new THREE.Shape();
stegoPlateShape.moveTo(0, 0.8);
stegoPlateShape.lineTo(-0.3, 0.2);
stegoPlateShape.lineTo(-0.35, 0);
stegoPlateShape.lineTo(-0.3, -0.2);
stegoPlateShape.lineTo(0, -0.7);
stegoPlateShape.lineTo(0.3, -0.2);
stegoPlateShape.lineTo(0.35, 0);
stegoPlateShape.lineTo(0.3, 0.2);
stegoPlateShape.lineTo(0, 0.8);
const stegoExtrudeSettings = { depth: 0.08, bevelEnabled: true, bevelThickness: 0.02, bevelSize: 0.02, bevelSegments: 2 };
const stegoPlateGeom = new THREE.ExtrudeGeometry(stegoPlateShape, stegoExtrudeSettings);
const stegoPlateMat = new THREE.MeshPhongMaterial({ color: 0xfb8c00 });

const stegoPlatePositions = [
    [1.0, 1.9, 0.08], [0.6, 2.0, -0.08], [0.2, 2.1, 0.08],
    [-0.2, 2.0, -0.08], [-0.6, 1.9, 0.08], [-1.0, 1.7, -0.08]
];

stegoPlatePositions.forEach((pos, i) => {
    const plate = new THREE.Mesh(stegoPlateGeom, stegoPlateMat);
    plate.position.set(pos[0], pos[1], pos[2]);
    plate.rotation.y = (i % 2 === 0) ? -0.15 : 0.15;
    plate.castShadow = true;
    stegosaurusGroup.add(plate);
});

// Queue (segments multiples)
const stegoTailBase = new THREE.CylinderGeometry(0.35, 0.25, 0.8, 12);
const stegoTailBaseM = new THREE.Mesh(stegoTailBase, stegoBodyMat);
stegoTailBaseM.rotation.z = Math.PI / 2.5;
stegoTailBaseM.position.set(-1.3, 1.2, 0);
stegoTailBaseM.castShadow = true;
stegosaurusGroup.add(stegoTailBaseM);

const stegoTailMid = new THREE.CylinderGeometry(0.25, 0.15, 0.7, 12);
const stegoTailMidM = new THREE.Mesh(stegoTailMid, stegoBodyMat);
stegoTailMidM.rotation.z = Math.PI / 2.2;
stegoTailMidM.position.set(-1.85, 1.0, 0);
stegoTailMidM.castShadow = true;
stegosaurusGroup.add(stegoTailMidM);

const stegoTailEndGeom = new THREE.CylinderGeometry(0.15, 0.08, 0.5, 12);
const stegoTailEnd = new THREE.Mesh(stegoTailEndGeom, stegoBodyMat);
stegoTailEnd.rotation.z = Math.PI / 2;
stegoTailEnd.position.set(-2.3, 0.8, 0);
stegoTailEnd.castShadow = true;
stegosaurusGroup.add(stegoTailEnd);

// Pointes de queue (Thagomizer - 4 pointes)
const stegoSpikeGeom = new THREE.ConeGeometry(0.08, 0.4, 8);
const stegoSpikeMat = new THREE.MeshPhongMaterial({ color: 0xd84315 });
const stegoSpikePositions = [
    [-2.4, 0.9, 0.15], [-2.4, 0.9, -0.15],
    [-2.5, 0.8, 0.2], [-2.5, 0.8, -0.2]
];
stegoSpikePositions.forEach((pos, i) => {
    const spike = new THREE.Mesh(stegoSpikeGeom, stegoSpikeMat);
    spike.position.set(pos[0], pos[1], pos[2]);
    spike.rotation.z = Math.PI / 2 + (i < 2 ? 0.3 : 0.5);
    spike.rotation.y = (i % 2 === 0) ? 0.2 : -0.2;
    stegosaurusGroup.add(spike);
});

// Jambes (pattes arrière plus longues)
const stegoLegFrontGeom = new THREE.CylinderGeometry(0.18, 0.22, 0.9, 12);
const stegoLegBackGeom = new THREE.CylinderGeometry(0.22, 0.26, 1.2, 12);

// Pattes avant
const stegoLegFL = new THREE.Mesh(stegoLegFrontGeom, stegoBodyMat);
stegoLegFL.position.set(0.8, 0.45, 0.45);
stegoLegFL.castShadow = true;
stegosaurusGroup.add(stegoLegFL);

const stegoLegFR = new THREE.Mesh(stegoLegFrontGeom, stegoBodyMat);
stegoLegFR.position.set(0.8, 0.45, -0.45);
stegoLegFR.castShadow = true;
stegosaurusGroup.add(stegoLegFR);

// Pattes arrière
const stegoLegBL = new THREE.Mesh(stegoLegBackGeom, stegoBodyMat);
stegoLegBL.position.set(-0.7, 0.6, 0.45);
stegoLegBL.castShadow = true;
stegosaurusGroup.add(stegoLegBL);

const stegoLegBR = new THREE.Mesh(stegoLegBackGeom, stegoBodyMat);
stegoLegBR.position.set(-0.7, 0.6, -0.45);
stegoLegBR.castShadow = true;
stegosaurusGroup.add(stegoLegBR);

// Pieds
const stegoFootGeom = new THREE.BoxGeometry(0.35, 0.15, 0.3);
[[0.8, 0.075, 0.45], [0.8, 0.075, -0.45], [-0.7, 0.075, 0.45], [-0.7, 0.075, -0.45]].forEach(pos => {
    const foot = new THREE.Mesh(stegoFootGeom, stegoBodyMat);
    foot.position.set(pos[0], pos[1], pos[2]);
    foot.castShadow = true;
    stegosaurusGroup.add(foot);
});

// Positionnement
stegosaurusGroup.rotation.y = 5 * Math.PI / 4;
stegosaurusGroup.scale.set(0.7, 0.7, 0.7);
stegosaurusGroup.position.set(positions[2][0], positions[2][1], positions[2][2]);
scene.add(stegosaurusGroup);

// === BRACHIOSAURE (Version améliorée) ===
const brachiosaurusGroup = new THREE.Group();

// Matériaux
const brachioBodyMat = new THREE.MeshPhongMaterial({ color: 0x1565c0, shininess: 30 });
const brachioBellyMat = new THREE.MeshPhongMaterial({ color: 0x1976d2 });
const brachioAccentMat = new THREE.MeshPhongMaterial({ color: 0x0d47a1 });
const brachioEyeMat = new THREE.MeshPhongMaterial({ color: 0xffeb3b, emissive: 0x333300 });

// Corps principal (forme ellipsoïdale)
const brachioBodyGeom = new THREE.SphereGeometry(1, 16, 16);
const brachioBody = new THREE.Mesh(brachioBodyGeom, brachioBodyMat);
brachioBody.scale.set(1.5, 1.1, 0.9);
brachioBody.position.y = 2.2;
brachioBody.castShadow = true;
brachiosaurusGroup.add(brachioBody);

// Ventre (partie inférieure plus claire)
const brachioVentreGeom = new THREE.SphereGeometry(0.9, 16, 16);
const brachioVentre = new THREE.Mesh(brachioVentreGeom, brachioBellyMat);
brachioVentre.scale.set(1.3, 0.8, 0.8);
brachioVentre.position.y = 1.7;
brachiosaurusGroup.add(brachioVentre);

// Bosse caractéristique sur le dos
const brachioHumpGeom = new THREE.SphereGeometry(0.5, 12, 12);
const brachioHump = new THREE.Mesh(brachioHumpGeom, brachioBodyMat);
brachioHump.scale.set(1, 1.2, 0.8);
brachioHump.position.set(0.8, 3, 0);
brachioHump.castShadow = true;
brachiosaurusGroup.add(brachioHump);

// Cou segmenté (5 segments pour plus de fluidité)
const neckSegments = [];
const neckSegmentCount = 5;
const neckHeight = 3.5;
const neckStartY = 2.8;
const neckStartX = 1.2;
const neckEndX = 2.5;
const neckEndY = neckStartY + neckHeight;

for (let i = 0; i < neckSegmentCount; i++) {
    const ratio = i / (neckSegmentCount - 1);
    const segmentRadius = 0.35 - (ratio * 0.15); // Diminue vers le haut
    const segmentHeight = neckHeight / (neckSegmentCount - 1);
    
    const neckSegGeom = new THREE.CylinderGeometry(segmentRadius * 0.9, segmentRadius, segmentHeight * 1.1, 12);
    const neckSeg = new THREE.Mesh(neckSegGeom, brachioBodyMat);
    
    const posX = neckStartX + (neckEndX - neckStartX) * ratio;
    const posY = neckStartY + (neckHeight * ratio);
    
    neckSeg.position.set(posX, posY, 0);
    neckSeg.rotation.z = -Math.PI / 7 - (ratio * 0.1);
    neckSeg.castShadow = true;
    neckSegments.push(neckSeg);
    brachiosaurusGroup.add(neckSeg);
}
const neck = neckSegments[0]; // Pour l'animation

// Tête (plus détaillée)
const brachioHeadGeom = new THREE.BoxGeometry(0.7, 0.8, 0.6);
const brachioHead = new THREE.Mesh(brachioHeadGeom, brachioBodyMat);
brachioHead.position.set(2.8, 6.2, 0);
brachioHead.castShadow = true;
brachiosaurusGroup.add(brachioHead);

// Museau/nez proéminent (bosse nasale caractéristique)
const brachioNoseGeom = new THREE.SphereGeometry(0.25, 12, 12);
const brachioNose = new THREE.Mesh(brachioNoseGeom, brachioAccentMat);
brachioNose.scale.set(0.8, 1.2, 0.9);
brachioNose.position.set(3.1, 6.5, 0);
brachioNose.castShadow = true;
brachiosaurusGroup.add(brachioNose);

// Mâchoire inférieure
const brachioJawGeom = new THREE.BoxGeometry(0.5, 0.3, 0.5);
const brachioJaw = new THREE.Mesh(brachioJawGeom, brachioBodyMat);
brachioJaw.position.set(3.0, 5.9, 0);
brachiosaurusGroup.add(brachioJaw);

// Narines
const nostrilGeom = new THREE.SphereGeometry(0.08, 8, 8);
const nostrilMat = new THREE.MeshPhongMaterial({ color: 0x000000 });
const nostrilLeft = new THREE.Mesh(nostrilGeom, nostrilMat);
nostrilLeft.position.set(3.2, 6.6, 0.15);
brachiosaurusGroup.add(nostrilLeft);
const nostrilRight = new THREE.Mesh(nostrilGeom, nostrilMat);
nostrilRight.position.set(3.2, 6.6, -0.15);
brachiosaurusGroup.add(nostrilRight);

// Yeux (plus expressifs)
const brachioEyeGeom = new THREE.SphereGeometry(0.12, 12, 12);
const brachioEyeLeft = new THREE.Mesh(brachioEyeGeom, brachioEyeMat);
brachioEyeLeft.position.set(2.9, 6.4, 0.35);
brachiosaurusGroup.add(brachioEyeLeft);
const brachioEyeRight = new THREE.Mesh(brachioEyeGeom, brachioEyeMat);
brachioEyeRight.position.set(2.9, 6.4, -0.35);
brachiosaurusGroup.add(brachioEyeRight);

// Pupilles
const brachioPupilGeom = new THREE.SphereGeometry(0.06, 8, 8);
const brachioPupilMat = new THREE.MeshPhongMaterial({ color: 0x000000 });
const brachioPupilLeft = new THREE.Mesh(brachioPupilGeom, brachioPupilMat);
brachioPupilLeft.position.set(3.0, 6.4, 0.4);
brachiosaurusGroup.add(brachioPupilLeft);
const brachioPupilRight = new THREE.Mesh(brachioPupilGeom, brachioPupilMat);
brachioPupilRight.position.set(3.0, 6.4, -0.4);
brachiosaurusGroup.add(brachioPupilRight);

// Queue (segments multiples)
const brachioTailBaseGeom = new THREE.CylinderGeometry(0.45, 0.35, 0.8, 12);
const brachioTailBase = new THREE.Mesh(brachioTailBaseGeom, brachioBodyMat);
brachioTailBase.rotation.z = Math.PI / 2.5;
brachioTailBase.position.set(-1.8, 2, 0);
brachioTailBase.castShadow = true;
brachiosaurusGroup.add(brachioTailBase);

const brachioTailMidGeom = new THREE.CylinderGeometry(0.35, 0.2, 1.2, 12);
const brachioTailMid = new THREE.Mesh(brachioTailMidGeom, brachioBodyMat);
brachioTailMid.rotation.z = Math.PI / 2.2;
brachioTailMid.position.set(-2.6, 1.7, 0);
brachioTailMid.castShadow = true;
brachiosaurusGroup.add(brachioTailMid);

const brachioTailEndGeom = new THREE.ConeGeometry(0.2, 1, 12);
const brachioTail = new THREE.Mesh(brachioTailEndGeom, brachioBodyMat);
brachioTail.rotation.z = Math.PI / 2;
brachioTail.position.set(-3.5, 1.4, 0);
brachioTail.castShadow = true;
brachiosaurusGroup.add(brachioTail);

// Jambes (pattes avant plus longues que l'arrière - caractéristique du brachiosaure)
const brachioLegFrontGeom = new THREE.CylinderGeometry(0.32, 0.35, 2.2, 12);
const brachioLegBackGeom = new THREE.CylinderGeometry(0.28, 0.32, 1.6, 12);

// Pattes avant
const brachioLegFL = new THREE.Mesh(brachioLegFrontGeom, brachioBodyMat);
brachioLegFL.position.set(1.2, 1.1, 0.65);
brachioLegFL.castShadow = true;
brachiosaurusGroup.add(brachioLegFL);

const brachioLegFR = new THREE.Mesh(brachioLegFrontGeom, brachioBodyMat);
brachioLegFR.position.set(1.2, 1.1, -0.65);
brachioLegFR.castShadow = true;
brachiosaurusGroup.add(brachioLegFR);

// Pattes arrière
const brachioLegBL = new THREE.Mesh(brachioLegBackGeom, brachioBodyMat);
brachioLegBL.position.set(-0.8, 0.8, 0.65);
brachioLegBL.castShadow = true;
brachiosaurusGroup.add(brachioLegBL);

const brachioLegBR = new THREE.Mesh(brachioLegBackGeom, brachioBodyMat);
brachioLegBR.position.set(-0.8, 0.8, -0.65);
brachioLegBR.castShadow = true;
brachiosaurusGroup.add(brachioLegBR);

// Pieds (larges et plats)
const brachioFootGeom = new THREE.CylinderGeometry(0.4, 0.42, 0.25, 12);
const footPositions = [[1.2, 0.125, 0.65], [1.2, 0.125, -0.65], [-0.8, 0.125, 0.65], [-0.8, 0.125, -0.65]];
footPositions.forEach(pos => {
    const foot = new THREE.Mesh(brachioFootGeom, brachioAccentMat);
    foot.position.set(pos[0], pos[1], pos[2]);
    foot.castShadow = true;
    brachiosaurusGroup.add(foot);
});

// Positionnement
brachiosaurusGroup.rotation.y = 5 * Math.PI / 4;
brachiosaurusGroup.scale.set(0.5, 0.5, 0.5);
brachiosaurusGroup.position.set(positions[3][0], positions[3][1], positions[3][2]);
scene.add(brachiosaurusGroup);

// === VÉLOCIRAPTOR (Version améliorée) ===
const velociraptorGroup = new THREE.Group();

// Matériaux
const raptorBodyMat = new THREE.MeshPhongMaterial({ color: 0xc62828, shininess: 40 });
const raptorFeatherMat = new THREE.MeshPhongMaterial({ color: 0xd32f2f });
const raptorClawMat = new THREE.MeshPhongMaterial({ color: 0x5d4037, shininess: 60 });
const raptorEyeMat = new THREE.MeshPhongMaterial({ color: 0xffd600, emissive: 0x332200 });
const raptorTeethMat = new THREE.MeshPhongMaterial({ color: 0xffffff });

// Corps principal (ellipsoïdal, incliné pour posture dynamique)
const raptorBodyGeom = new THREE.SphereGeometry(0.5, 16, 16);
const raptorBody = new THREE.Mesh(raptorBodyGeom, raptorBodyMat);
raptorBody.scale.set(1.8, 0.9, 0.7);
raptorBody.position.set(0, 1.8, 0);
raptorBody.rotation.z = 0.1; // Légère inclinaison
raptorBody.castShadow = true;
velociraptorGroup.add(raptorBody);

// Poitrine/cage thoracique
const raptorChestGeom = new THREE.SphereGeometry(0.35, 12, 12);
const raptorChest = new THREE.Mesh(raptorChestGeom, raptorBodyMat);
raptorChest.scale.set(1, 1.1, 0.9);
raptorChest.position.set(0.6, 1.9, 0);
raptorChest.castShadow = true;
velociraptorGroup.add(raptorChest);

// Cou
const raptorNeckGeom = new THREE.CylinderGeometry(0.18, 0.22, 0.5, 12);
const raptorNeck = new THREE.Mesh(raptorNeckGeom, raptorBodyMat);
raptorNeck.position.set(1, 2.1, 0);
raptorNeck.rotation.z = -Math.PI / 8;
raptorNeck.castShadow = true;
velociraptorGroup.add(raptorNeck);

// Tête (plus allongée et réaliste)
const raptorHeadGeom = new THREE.BoxGeometry(0.5, 0.4, 0.4);
const raptorHead = new THREE.Mesh(raptorHeadGeom, raptorBodyMat);
raptorHead.position.set(1.35, 2.2, 0);
raptorHead.castShadow = true;
velociraptorGroup.add(raptorHead);

// Museau allongé
const raptorSnoutGeom = new THREE.ConeGeometry(0.2, 0.5, 8);
const raptorSnout = new THREE.Mesh(raptorSnoutGeom, raptorBodyMat);
raptorSnout.rotation.z = -Math.PI / 2;
raptorSnout.position.set(1.65, 2.15, 0);
raptorSnout.castShadow = true;
velociraptorGroup.add(raptorSnout);

// Mâchoire inférieure
const raptorJawGeom = new THREE.BoxGeometry(0.4, 0.15, 0.35);
const raptorJaw = new THREE.Mesh(raptorJawGeom, raptorBodyMat);
raptorJaw.position.set(1.55, 2.05, 0);
velociraptorGroup.add(raptorJaw);

// Dents (petites et acérées)
const toothGeom = new THREE.ConeGeometry(0.03, 0.1, 6);
const toothPositions = [
    [1.5, 2.18, 0.1], [1.6, 2.18, 0.12], [1.7, 2.18, 0.1],
    [1.5, 2.18, -0.1], [1.6, 2.18, -0.12], [1.7, 2.18, -0.1]
];
toothPositions.forEach(pos => {
    const tooth = new THREE.Mesh(toothGeom, raptorTeethMat);
    tooth.position.set(pos[0], pos[1], pos[2]);
    tooth.rotation.x = Math.PI;
    velociraptorGroup.add(tooth);
});

// Yeux (plus expressifs et perçants)
const raptorEyeGeom = new THREE.SphereGeometry(0.1, 12, 12);
const raptorEyeLeft = new THREE.Mesh(raptorEyeGeom, raptorEyeMat);
raptorEyeLeft.position.set(1.5, 2.3, 0.22);
velociraptorGroup.add(raptorEyeLeft);
const raptorEyeRight = new THREE.Mesh(raptorEyeGeom, raptorEyeMat);
raptorEyeRight.position.set(1.5, 2.3, -0.22);
velociraptorGroup.add(raptorEyeRight);

// Pupilles fendues (comme un reptile)
const raptorPupilGeom = new THREE.BoxGeometry(0.03, 0.08, 0.03);
const raptorPupilMat = new THREE.MeshPhongMaterial({ color: 0x000000 });
const raptorPupilLeft = new THREE.Mesh(raptorPupilGeom, raptorPupilMat);
raptorPupilLeft.position.set(1.55, 2.3, 0.25);
velociraptorGroup.add(raptorPupilLeft);
const raptorPupilRight = new THREE.Mesh(raptorPupilGeom, raptorPupilMat);
raptorPupilRight.position.set(1.55, 2.3, -0.25);
velociraptorGroup.add(raptorPupilRight);

// Crête/plumes sur la tête
const raptorCrestGeom = new THREE.BoxGeometry(0.15, 0.25, 0.05);
const raptorCrest = new THREE.Mesh(raptorCrestGeom, raptorFeatherMat);
raptorCrest.position.set(1.35, 2.45, 0);
velociraptorGroup.add(raptorCrest);

// Bras longs avec griffes (caractéristique importante)
const raptorArmGeom = new THREE.CylinderGeometry(0.08, 0.06, 0.6, 8);

// Bras gauche
const raptorArmLeft = new THREE.Mesh(raptorArmGeom, raptorBodyMat);
raptorArmLeft.position.set(0.7, 1.8, 0.4);
raptorArmLeft.rotation.z = Math.PI / 3;
raptorArmLeft.castShadow = true;
velociraptorGroup.add(raptorArmLeft);

// Avant-bras gauche
const raptorForearmLeft = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.04, 0.5, 8), raptorBodyMat);
raptorForearmLeft.position.set(0.5, 1.5, 0.5);
raptorForearmLeft.rotation.z = Math.PI / 4;
velociraptorGroup.add(raptorForearmLeft);

// Griffes de main gauche
const handClawGeom = new THREE.ConeGeometry(0.03, 0.15, 6);
[[0.4, 1.35, 0.55], [0.35, 1.32, 0.58]].forEach(pos => {
    const claw = new THREE.Mesh(handClawGeom, raptorClawMat);
    claw.position.set(pos[0], pos[1], pos[2]);
    claw.rotation.z = Math.PI / 6;
    velociraptorGroup.add(claw);
});

// Bras droit
const raptorArmRight = new THREE.Mesh(raptorArmGeom, raptorBodyMat);
raptorArmRight.position.set(0.7, 1.8, -0.4);
raptorArmRight.rotation.z = Math.PI / 3;
raptorArmRight.castShadow = true;
velociraptorGroup.add(raptorArmRight);

// Avant-bras droit
const raptorForearmRight = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.04, 0.5, 8), raptorBodyMat);
raptorForearmRight.position.set(0.5, 1.5, -0.5);
raptorForearmRight.rotation.z = Math.PI / 4;
velociraptorGroup.add(raptorForearmRight);

// Griffes de main droite
[[0.4, 1.35, -0.55], [0.35, 1.32, -0.58]].forEach(pos => {
    const claw = new THREE.Mesh(handClawGeom, raptorClawMat);
    claw.position.set(pos[0], pos[1], pos[2]);
    claw.rotation.z = Math.PI / 6;
    velociraptorGroup.add(claw);
});

// Queue rigide et droite (caractéristique du vélociraptor)
const raptorTailSegments = [];

// Base de la queue
const raptorTailBaseGeom = new THREE.CylinderGeometry(0.25, 0.2, 0.6, 12);
const raptorTailBase = new THREE.Mesh(raptorTailBaseGeom, raptorBodyMat);
raptorTailBase.rotation.z = Math.PI / 2.2;
raptorTailBase.position.set(-0.8, 1.7, 0);
raptorTailBase.castShadow = true;
raptorTailSegments.push(raptorTailBase);
velociraptorGroup.add(raptorTailBase);

// Milieu de la queue
const raptorTailMidGeom = new THREE.CylinderGeometry(0.2, 0.12, 0.8, 12);
const raptorTailMid = new THREE.Mesh(raptorTailMidGeom, raptorBodyMat);
raptorTailMid.rotation.z = Math.PI / 2;
raptorTailMid.position.set(-1.5, 1.6, 0);
raptorTailMid.castShadow = true;
raptorTailSegments.push(raptorTailMid);
velociraptorGroup.add(raptorTailMid);

// Bout de la queue
const raptorTailEndGeom = new THREE.ConeGeometry(0.12, 0.8, 12);
const raptorTail = new THREE.Mesh(raptorTailEndGeom, raptorBodyMat);
raptorTail.rotation.z = Math.PI / 2;
raptorTail.position.set(-2.2, 1.6, 0);
raptorTail.castShadow = true;
raptorTailSegments.push(raptorTail);
velociraptorGroup.add(raptorTail);

// Plumes sur la queue
const featherGeom = new THREE.BoxGeometry(0.08, 0.15, 0.02);
for (let i = 0; i < 8; i++) {
    const feather = new THREE.Mesh(featherGeom, raptorFeatherMat);
    feather.position.set(-1.2 - (i * 0.15), 1.75, (i % 2 === 0 ? 0.1 : -0.1));
    feather.rotation.x = (i % 2 === 0 ? 0.3 : -0.3);
    velociraptorGroup.add(feather);
}

// Jambes (cuisses puissantes)
const raptorThighGeom = new THREE.CylinderGeometry(0.15, 0.12, 0.7, 12);

const raptorThighLeft = new THREE.Mesh(raptorThighGeom, raptorBodyMat);
raptorThighLeft.position.set(0.3, 1.3, 0.25);
raptorThighLeft.rotation.z = 0.2;
raptorThighLeft.castShadow = true;
velociraptorGroup.add(raptorThighLeft);

const raptorThighRight = new THREE.Mesh(raptorThighGeom, raptorBodyMat);
raptorThighRight.position.set(0.3, 1.3, -0.25);
raptorThighRight.rotation.z = 0.2;
raptorThighRight.castShadow = true;
velociraptorGroup.add(raptorThighRight);

// Tibias (fins et allongés)
const raptorShinGeom = new THREE.CylinderGeometry(0.1, 0.08, 0.8, 12);

const raptorShinLeft = new THREE.Mesh(raptorShinGeom, raptorBodyMat);
raptorShinLeft.position.set(0.4, 0.6, 0.25);
raptorShinLeft.rotation.z = -0.15;
raptorShinLeft.castShadow = true;
velociraptorGroup.add(raptorShinLeft);

const raptorShinRight = new THREE.Mesh(raptorShinGeom, raptorBodyMat);
raptorShinRight.position.set(0.4, 0.6, -0.25);
raptorShinRight.rotation.z = -0.15;
raptorShinRight.castShadow = true;
velociraptorGroup.add(raptorShinRight);

// Pieds
const raptorFootGeom = new THREE.BoxGeometry(0.5, 0.15, 0.2);

const raptorFootLeft = new THREE.Mesh(raptorFootGeom, raptorBodyMat);
raptorFootLeft.position.set(0.6, 0.15, 0.25);
raptorFootLeft.castShadow = true;
velociraptorGroup.add(raptorFootLeft);

const raptorFootRight = new THREE.Mesh(raptorFootGeom, raptorBodyMat);
raptorFootRight.position.set(0.6, 0.15, -0.25);
raptorFootRight.castShadow = true;
velociraptorGroup.add(raptorFootRight);

// GRIFFE EN FAUCILLE CARACTÉRISTIQUE (la fameuse griffe rétractable)
const sickleClawGeom = new THREE.ConeGeometry(0.08, 0.35, 8);

const sickleClawLeft = new THREE.Mesh(sickleClawGeom, raptorClawMat);
sickleClawLeft.position.set(0.75, 0.2, 0.32);
sickleClawLeft.rotation.z = -Math.PI / 3;
sickleClawLeft.castShadow = true;
velociraptorGroup.add(sickleClawLeft);

const sickleClawRight = new THREE.Mesh(sickleClawGeom, raptorClawMat);
sickleClawRight.position.set(0.75, 0.2, -0.32);
sickleClawRight.rotation.z = -Math.PI / 3;
sickleClawRight.castShadow = true;
velociraptorGroup.add(sickleClawRight);

// Griffes de pied normales
const footClawGeom = new THREE.ConeGeometry(0.04, 0.15, 6);
[[0.85, 0.12, 0.28], [0.85, 0.12, 0.22], [0.85, 0.12, -0.28], [0.85, 0.12, -0.22]].forEach(pos => {
    const claw = new THREE.Mesh(footClawGeom, raptorClawMat);
    claw.position.set(pos[0], pos[1], pos[2]);
    claw.rotation.z = -Math.PI / 4;
    velociraptorGroup.add(claw);
});

// Positionnement
velociraptorGroup.rotation.y = 5 * Math.PI / 4;
velociraptorGroup.scale.set(0.7, 0.7, 0.7);
velociraptorGroup.position.set(positions[4][0], positions[4][1], positions[4][2]);
scene.add(velociraptorGroup);

// === ANKYLOSAURE (Version améliorée - Tank blindé) ===
const ankylosaurusGroup = new THREE.Group();

// Matériaux
const ankyloBodyMat = new THREE.MeshPhongMaterial({ color: 0x6d4c41, shininess: 20 });
const ankyloArmorMat = new THREE.MeshPhongMaterial({ color: 0x5d4037, shininess: 50 });
const ankyloSpikeMat = new THREE.MeshPhongMaterial({ color: 0x4e342e, shininess: 70 });
const ankyloClubMat = new THREE.MeshPhongMaterial({ color: 0x3e2723, shininess: 30 });
const ankyloEyeMat = new THREE.MeshPhongMaterial({ color: 0xff6f00, emissive: 0x221100 });

// Corps principal (large et bas, comme un tank)
const ankyloBodyGeom = new THREE.SphereGeometry(1, 16, 16);
const ankyloBody = new THREE.Mesh(ankyloBodyGeom, ankyloBodyMat);
ankyloBody.scale.set(1.3, 0.6, 0.9);
ankyloBody.position.y = 1.2;
ankyloBody.castShadow = true;
ankylosaurusGroup.add(ankyloBody);

// Ventre (plus bas et plus large)
const ankyloVentreGeom = new THREE.SphereGeometry(0.9, 16, 16);
const ankyloVentre = new THREE.Mesh(ankyloVentreGeom, ankyloBodyMat);
ankyloVentre.scale.set(1.2, 0.5, 0.85);
ankyloVentre.position.y = 0.8;
ankylosaurusGroup.add(ankyloVentre);

// ARMURE DORSALE - Plaques osseuses hexagonales
const armorPlateGeom = new THREE.CylinderGeometry(0.15, 0.18, 0.12, 6);
const armorPlatePositions = [
    // Rangée centrale
    [0.8, 1.65, 0], [0.4, 1.68, 0], [0, 1.7, 0], [-0.4, 1.68, 0], [-0.8, 1.65, 0],
    // Rangée gauche
    [0.7, 1.6, 0.35], [0.3, 1.63, 0.35], [-0.1, 1.65, 0.35], [-0.5, 1.63, 0.35],
    // Rangée droite
    [0.7, 1.6, -0.35], [0.3, 1.63, -0.35], [-0.1, 1.65, -0.35], [-0.5, 1.63, -0.35],
    // Rangées extérieures
    [0.5, 1.55, 0.6], [0, 1.6, 0.6], [-0.5, 1.55, 0.6],
    [0.5, 1.55, -0.6], [0, 1.6, -0.6], [-0.5, 1.55, -0.6]
];
armorPlatePositions.forEach(pos => {
    const plate = new THREE.Mesh(armorPlateGeom, ankyloArmorMat);
    plate.position.set(pos[0], pos[1], pos[2]);
    plate.rotation.x = Math.PI / 2;
    plate.castShadow = true;
    ankylosaurusGroup.add(plate);
});

// POINTES DÉFENSIVES sur les côtés
const spikeGeom = new THREE.ConeGeometry(0.1, 0.35, 8);
const spikePositions = [
    // Côté gauche
    [0.8, 1.3, 0.85, 0.3], [0.3, 1.35, 0.9, 0.2], [-0.3, 1.35, 0.9, 0.2], [-0.8, 1.3, 0.85, 0.3],
    // Côté droit
    [0.8, 1.3, -0.85, -0.3], [0.3, 1.35, -0.9, -0.2], [-0.3, 1.35, -0.9, -0.2], [-0.8, 1.3, -0.85, -0.3]
];
spikePositions.forEach(pos => {
    const spike = new THREE.Mesh(spikeGeom, ankyloSpikeMat);
    spike.position.set(pos[0], pos[1], pos[2]);
    spike.rotation.z = pos[3];
    spike.castShadow = true;
    ankylosaurusGroup.add(spike);
});

// Cou court et large
const ankyloNeckGeom = new THREE.CylinderGeometry(0.28, 0.32, 0.4, 12);
const ankyloNeck = new THREE.Mesh(ankyloNeckGeom, ankyloBodyMat);
ankyloNeck.position.set(1.1, 1.05, 0);
ankyloNeck.rotation.z = -Math.PI / 12;
ankylosaurusGroup.add(ankyloNeck);

// Tête (large et blindée)
const ankyloHeadGeom = new THREE.BoxGeometry(0.7, 0.5, 0.65);
const ankyloHead = new THREE.Mesh(ankyloHeadGeom, ankyloBodyMat);
ankyloHead.position.set(1.55, 1.05, 0);
ankyloHead.castShadow = true;
ankylosaurusGroup.add(ankyloHead);

// Museau avec bec
const ankyloSnoutGeom = new THREE.BoxGeometry(0.35, 0.3, 0.5);
const ankyloSnout = new THREE.Mesh(ankyloSnoutGeom, ankyloBodyMat);
ankyloSnout.position.set(1.85, 0.95, 0);
ankylosaurusGroup.add(ankyloSnout);

// Plaques céphaliques (armure de tête)
const headArmorGeom = new THREE.BoxGeometry(0.2, 0.15, 0.2);
[[1.4, 1.25, 0.2], [1.4, 1.25, -0.2], [1.6, 1.25, 0.25], [1.6, 1.25, -0.25]].forEach(pos => {
    const armor = new THREE.Mesh(headArmorGeom, ankyloArmorMat);
    armor.position.set(pos[0], pos[1], pos[2]);
    armor.castShadow = true;
    ankylosaurusGroup.add(armor);
});

// Cornes au coin des yeux
const ankyloHornGeom = new THREE.ConeGeometry(0.08, 0.2, 8);
[[1.65, 1.15, 0.35], [1.65, 1.15, -0.35]].forEach((pos, i) => {
    const horn = new THREE.Mesh(ankyloHornGeom, ankyloSpikeMat);
    horn.position.set(pos[0], pos[1], pos[2]);
    horn.rotation.z = (i === 0) ? -0.5 : 0.5;
    horn.rotation.x = 0.3;
    ankylosaurusGroup.add(horn);
});

// Yeux (petits et protégés)
const ankyloEyeGeom = new THREE.SphereGeometry(0.09, 12, 12);
const ankyloEyeLeft = new THREE.Mesh(ankyloEyeGeom, ankyloEyeMat);
ankyloEyeLeft.position.set(1.75, 1.1, 0.28);
ankylosaurusGroup.add(ankyloEyeLeft);
const ankyloEyeRight = new THREE.Mesh(ankyloEyeGeom, ankyloEyeMat);
ankyloEyeRight.position.set(1.75, 1.1, -0.28);
ankylosaurusGroup.add(ankyloEyeRight);

// Pupilles
const anklyloPupilGeom = new THREE.SphereGeometry(0.04, 8, 8);
const anklyloPupilMat = new THREE.MeshPhongMaterial({ color: 0x000000 });
const anklyloPupilLeft = new THREE.Mesh(anklyloPupilGeom, anklyloPupilMat);
anklyloPupilLeft.position.set(1.82, 1.1, 0.3);
ankylosaurusGroup.add(anklyloPupilLeft);
const anklyloPupilRight = new THREE.Mesh(anklyloPupilGeom, anklyloPupilMat);
anklyloPupilRight.position.set(1.82, 1.1, -0.3);
ankylosaurusGroup.add(anklyloPupilRight);

// Queue (segmentée et flexible)
const ankyloTailBase = new THREE.CylinderGeometry(0.35, 0.28, 0.6, 12);
const tailBase1 = new THREE.Mesh(ankyloTailBase, ankyloBodyMat);
tailBase1.rotation.z = Math.PI / 2.3;
tailBase1.position.set(-1.3, 1.15, 0);
tailBase1.castShadow = true;
ankylosaurusGroup.add(tailBase1);

const ankyloTailMid = new THREE.CylinderGeometry(0.28, 0.22, 0.7, 12);
const ankyloTailMidMesh = new THREE.Mesh(ankyloTailMid, ankyloBodyMat);
ankyloTailMidMesh.rotation.z = Math.PI / 2.1;
ankyloTailMidMesh.position.set(-1.9, 1.05, 0);
ankyloTailMidMesh.castShadow = true;
ankylosaurusGroup.add(ankyloTailMidMesh);

const ankyloTailEnd = new THREE.CylinderGeometry(0.22, 0.18, 0.5, 12);
const ankyloTail = new THREE.Mesh(ankyloTailEnd, ankyloBodyMat);
ankyloTail.rotation.z = Math.PI / 2;
ankyloTail.position.set(-2.5, 1.0, 0);
ankyloTail.castShadow = true;
ankylosaurusGroup.add(ankyloTail);

// MASSUE CAUDALE (l'arme légendaire de l'ankylosaure)
// Base de la massue (os élargi)
const clubBaseGeom = new THREE.BoxGeometry(0.5, 0.35, 0.45);
const clubBase = new THREE.Mesh(clubBaseGeom, ankyloClubMat);
clubBase.position.set(-3.0, 1.0, 0);
clubBase.castShadow = true;
ankylosaurusGroup.add(clubBase);

// Parties latérales de la massue (nœuds osseux)
const clubKnobGeom = new THREE.SphereGeometry(0.25, 12, 12);

const clubKnobLeft = new THREE.Mesh(clubKnobGeom, ankyloClubMat);
clubKnobLeft.scale.set(1, 0.8, 1.2);
clubKnobLeft.position.set(-3.0, 1.0, 0.3);
clubKnobLeft.castShadow = true;
ankylosaurusGroup.add(clubKnobLeft);

const clubKnobRight = new THREE.Mesh(clubKnobGeom, ankyloClubMat);
clubKnobRight.scale.set(1, 0.8, 1.2);
clubKnobRight.position.set(-3.0, 1.0, -0.3);
clubKnobRight.castShadow = true;
ankylosaurusGroup.add(clubKnobRight);

// Pointes osseuses sur la massue
const clubSpikeGeom = new THREE.ConeGeometry(0.08, 0.2, 8);
const clubSpikePositions = [
    [-2.85, 1.15, 0.2], [-2.85, 1.15, -0.2],
    [-3.15, 1.15, 0.25], [-3.15, 1.15, -0.25],
    [-3.0, 1.2, 0], [-3.0, 0.85, 0.3], [-3.0, 0.85, -0.3]
];
clubSpikePositions.forEach(pos => {
    const spike = new THREE.Mesh(clubSpikeGeom, ankyloSpikeMat);
    spike.position.set(pos[0], pos[1], pos[2]);
    spike.rotation.x = Math.random() * 0.5 - 0.25;
    spike.rotation.z = Math.random() * 0.5 - 0.25;
    ankylosaurusGroup.add(spike);
});

// Groupe de la massue pour animation
const club = clubBase; // Référence pour l'animation

// Jambes robustes et courtes (comme un tank)
const ankyloThighGeom = new THREE.CylinderGeometry(0.24, 0.22, 0.5, 12);
const ankyloShinGeom = new THREE.CylinderGeometry(0.2, 0.18, 0.4, 12);

const legPositions = [
    [0.9, 0.6, 0.7],   // Avant gauche
    [0.9, 0.6, -0.7],  // Avant droit
    [-0.7, 0.6, 0.7],  // Arrière gauche
    [-0.7, 0.6, -0.7]  // Arrière droit
];

legPositions.forEach(pos => {
    // Cuisse
    const thigh = new THREE.Mesh(ankyloThighGeom, ankyloBodyMat);
    thigh.position.set(pos[0], pos[1], pos[2]);
    thigh.castShadow = true;
    ankylosaurusGroup.add(thigh);
    
    // Tibia
    const shin = new THREE.Mesh(ankyloShinGeom, ankyloBodyMat);
    shin.position.set(pos[0], pos[1] - 0.45, pos[2]);
    shin.castShadow = true;
    ankylosaurusGroup.add(shin);
});

// Pieds larges et plats
const ankyloFootGeom = new THREE.CylinderGeometry(0.22, 0.25, 0.15, 12);
legPositions.forEach(pos => {
    const foot = new THREE.Mesh(ankyloFootGeom, ankyloArmorMat);
    foot.position.set(pos[0], 0.1, pos[2]);
    foot.castShadow = true;
    ankylosaurusGroup.add(foot);
});

// Positionnement
ankylosaurusGroup.rotation.y = 5 * Math.PI / 4;
ankylosaurusGroup.scale.set(0.6, 0.6, 0.6);
ankylosaurusGroup.position.set(positions[5][0], positions[5][1], positions[5][2]);
scene.add(ankylosaurusGroup);

// === PTÉRODACTYLE (Version améliorée - Reptile volant) ===
const pterodactylGroup = new THREE.Group();

// Matériaux
const pteroBodyMat = new THREE.MeshPhongMaterial({ color: 0x00897b, shininess: 30 });
const pteroWingMat = new THREE.MeshPhongMaterial({ 
    color: 0x26a69a, 
    shininess: 10,
    transparent: true, 
    opacity: 0.9,
    side: THREE.DoubleSide 
});
const pteroCrestMat = new THREE.MeshPhongMaterial({ color: 0xff6f00, shininess: 40 });
const pteroEyeMat = new THREE.MeshPhongMaterial({ color: 0xffeb3b, emissive: 0x332200 });
const pteroClawMat = new THREE.MeshPhongMaterial({ color: 0x263238, shininess: 60 });

// Corps (compact et aérodynamique)
const pteroBodyGeom = new THREE.SphereGeometry(0.35, 16, 16);
const pteroBody = new THREE.Mesh(pteroBodyGeom, pteroBodyMat);
pteroBody.scale.set(0.8, 1.2, 0.6);
pteroBody.position.y = 1.8;
pteroBody.castShadow = true;
pterodactylGroup.add(pteroBody);

// Poitrine (muscles pectoraux puissants pour le vol)
const pteroChestGeom = new THREE.SphereGeometry(0.3, 12, 12);
const pteroChest = new THREE.Mesh(pteroChestGeom, pteroBodyMat);
pteroChest.scale.set(1.1, 0.8, 0.9);
pteroChest.position.y = 1.7;
pteroChest.castShadow = true;
pterodactylGroup.add(pteroChest);

// Cou allongé
const pteroNeckGeom = new THREE.CylinderGeometry(0.12, 0.15, 0.5, 12);
const pteroNeck = new THREE.Mesh(pteroNeckGeom, pteroBodyMat);
pteroNeck.position.set(0, 2.15, 0.25);
pteroNeck.rotation.x = Math.PI / 6;
pteroNeck.castShadow = true;
pterodactylGroup.add(pteroNeck);

// Tête (allongée)
const pteroHeadGeom = new THREE.BoxGeometry(0.35, 0.3, 0.4);
const pteroHead = new THREE.Mesh(pteroHeadGeom, pteroBodyMat);
pteroHead.position.set(0, 2.35, 0.5);
pteroHead.castShadow = true;
pterodactylGroup.add(pteroHead);

// Long bec (caractéristique)
const pteroBeakGeom = new THREE.ConeGeometry(0.12, 0.8, 8);
const pteroBeak = new THREE.Mesh(pteroBeakGeom, pteroBodyMat);
pteroBeak.rotation.x = Math.PI / 2;
pteroBeak.position.set(0, 2.3, 0.9);
pteroBeakGeom.castShadow = true;
pterodactylGroup.add(pteroBeak);

// Mâchoire inférieure
const pteroJawGeom = new THREE.ConeGeometry(0.1, 0.6, 8);
const pteroJaw = new THREE.Mesh(pteroJawGeom, pteroBodyMat);
pteroJaw.rotation.x = Math.PI / 2;
pteroJaw.position.set(0, 2.2, 0.85);
pterodactylGroup.add(pteroJaw);

// CRÊTE CÉPHALIQUE (très caractéristique des ptérosaures)
const pteroCrestGeom = new THREE.BoxGeometry(0.15, 0.8, 0.08);
const pteroCrest = new THREE.Mesh(pteroCrestGeom, pteroCrestMat);
pteroCrest.position.set(0, 2.7, 0.5);
pteroCrest.rotation.x = -0.3;
pteroCrest.castShadow = true;
pterodactylGroup.add(pteroCrest);

// Yeux (grands pour la vision aérienne)
const pteroEyeGeom = new THREE.SphereGeometry(0.1, 12, 12);
const pteroEyeLeft = new THREE.Mesh(pteroEyeGeom, pteroEyeMat);
pteroEyeLeft.position.set(0.18, 2.4, 0.65);
pterodactylGroup.add(pteroEyeLeft);
const pteroEyeRight = new THREE.Mesh(pteroEyeGeom, pteroEyeMat);
pteroEyeRight.position.set(-0.18, 2.4, 0.65);
pterodactylGroup.add(pteroEyeRight);

// Pupilles
const pteroPupilGeom = new THREE.SphereGeometry(0.04, 8, 8);
const pteroPupilMat = new THREE.MeshPhongMaterial({ color: 0x000000 });
const pteroPupilLeft = new THREE.Mesh(pteroPupilGeom, pteroPupilMat);
pteroPupilLeft.position.set(0.22, 2.4, 0.7);
pterodactylGroup.add(pteroPupilLeft);
const pteroPupilRight = new THREE.Mesh(pteroPupilGeom, pteroPupilMat);
pteroPupilRight.position.set(-0.22, 2.4, 0.7);
pterodactylGroup.add(pteroPupilRight);

// AILES MEMBRANEUSES (structure réaliste)
// Bras (os du bras)
const pteroArmGeom = new THREE.CylinderGeometry(0.08, 0.06, 0.6, 8);

const pteroArmLeft = new THREE.Mesh(pteroArmGeom, pteroBodyMat);
pteroArmLeft.position.set(0.45, 1.75, 0.1);
pteroArmLeft.rotation.z = Math.PI / 3;
pteroArmLeft.castShadow = true;
pterodactylGroup.add(pteroArmLeft);

const pteroArmRight = new THREE.Mesh(pteroArmGeom, pteroBodyMat);
pteroArmRight.position.set(-0.45, 1.75, 0.1);
pteroArmRight.rotation.z = -Math.PI / 3;
pteroArmRight.castShadow = true;
pterodactylGroup.add(pteroArmRight);

// Avant-bras
const pteroForearmGeom = new THREE.CylinderGeometry(0.06, 0.04, 0.5, 8);

const pteroForearmLeft = new THREE.Mesh(pteroForearmGeom, pteroBodyMat);
pteroForearmLeft.position.set(0.75, 1.5, 0.15);
pteroForearmLeft.rotation.z = Math.PI / 4;
pterodactylGroup.add(pteroForearmLeft);

const pteroForearmRight = new THREE.Mesh(pteroForearmGeom, pteroBodyMat);
pteroForearmRight.position.set(-0.75, 1.5, 0.15);
pteroForearmRight.rotation.z = -Math.PI / 4;
pterodactylGroup.add(pteroForearmRight);

// Doigt wing (le 4ème doigt énormément allongé qui supporte l'aile)
const pteroWingFingerGeom = new THREE.CylinderGeometry(0.04, 0.02, 1.5, 8);

const pteroWingFingerLeft = new THREE.Mesh(pteroWingFingerGeom, pteroBodyMat);
pteroWingFingerLeft.position.set(1.5, 1.5, 0.2);
pteroWingFingerLeft.rotation.z = Math.PI / 2.5;
pterodactylGroup.add(pteroWingFingerLeft);

const pteroWingFingerRight = new THREE.Mesh(pteroWingFingerGeom, pteroBodyMat);
pteroWingFingerRight.position.set(-1.5, 1.5, 0.2);
pteroWingFingerRight.rotation.z = -Math.PI / 2.5;
pterodactylGroup.add(pteroWingFingerRight);

// Membrane alaire (patagium)
const wingMembraneShape = new THREE.Shape();
wingMembraneShape.moveTo(0, 0);
wingMembraneShape.lineTo(1.8, 0.3);
wingMembraneShape.quadraticCurveTo(2, 0.1, 2.1, -0.2);
wingMembraneShape.lineTo(1.5, -0.8);
wingMembraneShape.quadraticCurveTo(0.8, -0.6, 0, -0.4);
wingMembraneShape.lineTo(0, 0);

const wingMembraneGeom = new THREE.ExtrudeGeometry(wingMembraneShape, { 
    depth: 0.02, 
    bevelEnabled: false 
});

const pteroWingLeft = new THREE.Mesh(wingMembraneGeom, pteroWingMat);
pteroWingLeft.position.set(0.4, 1.7, 0);
pteroWingLeft.rotation.y = Math.PI / 2;
pteroWingLeft.castShadow = true;
pterodactylGroup.add(pteroWingLeft);

const pteroWingRight = new THREE.Mesh(wingMembraneGeom, pteroWingMat);
pteroWingRight.position.set(-0.4, 1.7, 0);
pteroWingRight.rotation.y = -Math.PI / 2;
pteroWingRight.scale.x = -1;
pteroWingRight.castShadow = true;
pterodactylGroup.add(pteroWingRight);

// Griffes aux ailes (3 petits doigts)
const pteroWingClawGeom = new THREE.ConeGeometry(0.02, 0.1, 6);
[[0.9, 1.65, 0.25], [0.95, 1.6, 0.28], [1.0, 1.55, 0.3]].forEach(pos => {
    const claw = new THREE.Mesh(pteroWingClawGeom, pteroClawMat);
    claw.position.set(pos[0], pos[1], pos[2]);
    claw.rotation.z = Math.PI / 4;
    pterodactylGroup.add(claw);
});
[[-0.9, 1.65, 0.25], [-0.95, 1.6, 0.28], [-1.0, 1.55, 0.3]].forEach(pos => {
    const claw = new THREE.Mesh(pteroWingClawGeom, pteroClawMat);
    claw.position.set(pos[0], pos[1], pos[2]);
    claw.rotation.z = -Math.PI / 4;
    pterodactylGroup.add(claw);
});

// Queue courte et pointue
const pteroTailGeom = new THREE.ConeGeometry(0.08, 0.4, 8);
const pteroTail = new THREE.Mesh(pteroTailGeom, pteroBodyMat);
pteroTail.rotation.x = -Math.PI / 2;
pteroTail.position.set(0, 1.65, -0.4);
pteroTail.castShadow = true;
pterodactylGroup.add(pteroTail);

// PATTES (petites mais avec griffes puissantes)
const pteroThighGeom = new THREE.CylinderGeometry(0.08, 0.06, 0.35, 8);

const pteroThighLeft = new THREE.Mesh(pteroThighGeom, pteroBodyMat);
pteroThighLeft.position.set(0.2, 1.45, -0.15);
pteroThighLeft.rotation.z = 0.3;
pterodactylGroup.add(pteroThighLeft);

const pteroThighRight = new THREE.Mesh(pteroThighGeom, pteroBodyMat);
pteroThighRight.position.set(-0.2, 1.45, -0.15);
pteroThighRight.rotation.z = -0.3;
pterodactylGroup.add(pteroThighRight);

// Tibias
const pteroShinGeom = new THREE.CylinderGeometry(0.06, 0.04, 0.4, 8);

const pteroShinLeft = new THREE.Mesh(pteroShinGeom, pteroBodyMat);
pteroShinLeft.position.set(0.3, 1.15, -0.25);
pteroShinLeft.rotation.z = -0.2;
pterodactylGroup.add(pteroShinLeft);

const pteroShinRight = new THREE.Mesh(pteroShinGeom, pteroBodyMat);
pteroShinRight.position.set(-0.3, 1.15, -0.25);
pteroShinRight.rotation.z = 0.2;
pterodactylGroup.add(pteroShinRight);

// Pieds avec griffes
const pteroFootGeom = new THREE.BoxGeometry(0.15, 0.08, 0.12);

const pteroFootLeft = new THREE.Mesh(pteroFootGeom, pteroBodyMat);
pteroFootLeft.position.set(0.25, 1.0, -0.3);
pterodactylGroup.add(pteroFootLeft);

const pteroFootRight = new THREE.Mesh(pteroFootGeom, pteroBodyMat);
pteroFootRight.position.set(-0.25, 1.0, -0.3);
pterodactylGroup.add(pteroFootRight);

// Griffes des pieds (pour s'accrocher)
const pteroFootClawGeom = new THREE.ConeGeometry(0.03, 0.12, 6);
[[0.3, 0.98, -0.28], [0.25, 0.98, -0.32], [0.2, 0.98, -0.3]].forEach(pos => {
    const claw = new THREE.Mesh(pteroFootClawGeom, pteroClawMat);
    claw.position.set(pos[0], pos[1], pos[2]);
    claw.rotation.x = Math.PI / 6;
    pterodactylGroup.add(claw);
});
[[-0.3, 0.98, -0.28], [-0.25, 0.98, -0.32], [-0.2, 0.98, -0.3]].forEach(pos => {
    const claw = new THREE.Mesh(pteroFootClawGeom, pteroClawMat);
    claw.position.set(pos[0], pos[1], pos[2]);
    claw.rotation.x = Math.PI / 6;
    pterodactylGroup.add(claw);
});

// Positionnement
pterodactylGroup.rotation.y = 7 * Math.PI / 4;
pterodactylGroup.scale.set(0.8, 0.8, 0.8);
pterodactylGroup.position.set(positions[6][0], positions[6][1], positions[6][2]);
scene.add(pterodactylGroup);

// === SPINOSAURE ===
const spinosaurusGroup = new THREE.Group();

// Corps
const spinoBodyGeom = new THREE.BoxGeometry(2.8, 1.2, 1);
const spinoBodyMat = new THREE.MeshPhongMaterial({ color: 0xad1457 });
const spinoBody = new THREE.Mesh(spinoBodyGeom, spinoBodyMat);
spinoBody.position.y = 1.5;
spinosaurusGroup.add(spinoBody);

// Tête
const spinoHeadGeom = new THREE.BoxGeometry(1.2, 0.8, 0.6);
const spinoHead = new THREE.Mesh(spinoHeadGeom, spinoBodyMat);
spinoHead.position.set(1.8, 1.7, 0);
spinosaurusGroup.add(spinoHead);

// Yeux
const spinoEyeGeom = new THREE.SphereGeometry(0.1, 8, 8);
const spinoEyeMat = new THREE.MeshPhongMaterial({ color: 0xc2185b });
const spinoEyeLeft = new THREE.Mesh(spinoEyeGeom, spinoEyeMat);
spinoEyeLeft.position.set(2.2, 1.9, 0.2);
spinosaurusGroup.add(spinoEyeLeft);
const spinoEyeRight = new THREE.Mesh(spinoEyeGeom, spinoEyeMat);
spinoEyeRight.position.set(2.2, 1.9, -0.2);
spinosaurusGroup.add(spinoEyeRight);

// Voile dorsale
const sailGeom = new THREE.CylinderGeometry(0.8, 0.2, 0.1, 3);
const sail = new THREE.Mesh(sailGeom, spinoEyeMat);
sail.scale.set(2, 1, 1);
sail.rotation.x = Math.PI / 2;
sail.position.set(0, 2.5, 0);
spinosaurusGroup.add(sail);

// Queue
const spinoTailGeom = new THREE.ConeGeometry(0.3, 1.8, 8);
const spinoTail = new THREE.Mesh(spinoTailGeom, spinoBodyMat);
spinoTail.rotation.z = Math.PI / 2;
spinoTail.position.set(-2.2, 1.5, 0);
spinosaurusGroup.add(spinoTail);

// Jambes
const spinoLegGeom = new THREE.CylinderGeometry(0.2, 0.2, 1, 8);
const spinoLegPositions = [[1, 0.75, 0.4], [1, 0.75, -0.4], [-1, 0.75, 0.4], [-1, 0.75, -0.4]];
spinoLegPositions.forEach(pos => {
    const leg = new THREE.Mesh(spinoLegGeom, spinoBodyMat);
    leg.position.set(pos[0], pos[1], pos[2]);
    spinosaurusGroup.add(leg);
});

// Positionnement
spinosaurusGroup.rotation.y = 5 * Math.PI / 4;
spinosaurusGroup.scale.set(0.6, 0.6, 0.6);
spinosaurusGroup.position.set(positions[7][0], positions[7][1], positions[7][2]);
scene.add(spinosaurusGroup);

// === PARASAUROLOPHUS ===
const parasaurolophusGroup = new THREE.Group();

// Corps
const paraBodyGeom = new THREE.BoxGeometry(2.5, 1.3, 1);
const paraBodyMat = new THREE.MeshPhongMaterial({ color: 0x2e7d32 });
const paraBody = new THREE.Mesh(paraBodyGeom, paraBodyMat);
paraBody.position.y = 1.6;
parasaurolophusGroup.add(paraBody);

// Tête
const paraHeadGeom = new THREE.BoxGeometry(0.8, 0.7, 0.6);
const paraHead = new THREE.Mesh(paraHeadGeom, paraBodyMat);
paraHead.position.set(1.5, 1.8, 0);
parasaurolophusGroup.add(paraHead);

// Crête
const crestGeom = new THREE.CylinderGeometry(0.1, 0.05, 1.2, 8);
const crest = new THREE.Mesh(crestGeom, new THREE.MeshPhongMaterial({ color: 0x1b5e20 }));
crest.position.set(1.6, 2.2, 0);
crest.rotation.z = Math.PI / 4;
parasaurolophusGroup.add(crest);

// Yeux
const paraEyeGeom = new THREE.SphereGeometry(0.08, 8, 8);
const paraEyeMat = new THREE.MeshPhongMaterial({ color: 0x1b5e20 });
const paraEyeLeft = new THREE.Mesh(paraEyeGeom, paraEyeMat);
paraEyeLeft.position.set(1.7, 1.9, 0.2);
parasaurolophusGroup.add(paraEyeLeft);
const paraEyeRight = new THREE.Mesh(paraEyeGeom, paraEyeMat);
paraEyeRight.position.set(1.7, 1.9, -0.2);
parasaurolophusGroup.add(paraEyeRight);

// Queue
const paraTailGeom = new THREE.ConeGeometry(0.3, 1.5, 8);
const paraTail = new THREE.Mesh(paraTailGeom, paraBodyMat);
paraTail.rotation.z = Math.PI / 2;
paraTail.position.set(-2, 1.6, 0);
parasaurolophusGroup.add(paraTail);

// Jambes
const paraLegGeom = new THREE.CylinderGeometry(0.2, 0.2, 1.1, 8);
const paraLegPositions = [[1, 0.8, 0.4], [1, 0.8, -0.4], [-1, 0.8, 0.4], [-1, 0.8, -0.4]];
paraLegPositions.forEach(pos => {
    const leg = new THREE.Mesh(paraLegGeom, paraBodyMat);
    leg.position.set(pos[0], pos[1], pos[2]);
    parasaurolophusGroup.add(leg);
});

// Positionnement
parasaurolophusGroup.rotation.y = 5 * Math.PI / 4;
parasaurolophusGroup.scale.set(0.6, 0.6, 0.6);
parasaurolophusGroup.position.set(positions[8][0], positions[8][1], positions[8][2]);
scene.add(parasaurolophusGroup);
/*
// 3 Grilles visuelles pour débug, une pour chaque niveau
const gridSize = spacingX * 2.2;
const gridDivisions = 3;

const gridHelperTop = new THREE.GridHelper(gridSize, gridDivisions, 0x888888, 0xcccccc);
gridHelperTop.position.y = spacingY;
scene.add(gridHelperTop);

const gridHelperMiddle = new THREE.GridHelper(gridSize, gridDivisions, 0x888888, 0xcccccc);
gridHelperMiddle.position.y = 0;
scene.add(gridHelperMiddle);

const gridHelperBottom = new THREE.GridHelper(gridSize, gridDivisions, 0x888888, 0xcccccc);
gridHelperBottom.position.y = -spacingY;
scene.add(gridHelperBottom);

// Marqueurs pour chaque position de la grille
const markerGeometry = new THREE.CircleGeometry(0.3, 16);
const markerMaterial = new THREE.MeshBasicMaterial({ color: 0xff0000, side: THREE.DoubleSide });

for (let i = 0; i < positions.length; i++) {
    const marker = new THREE.Mesh(markerGeometry, markerMaterial);
    marker.rotation.x = -Math.PI / 2;
    marker.position.set(positions[i][0], positions[i][1] + 0.01, positions[i][2]);
    scene.add(marker);
}
*/
// Animation
let time = 0;
function animate() {
    requestAnimationFrame(animate);
    
    time += 0.01;
    
    // Animation de rotation du T-Rex - désactivée
    // trexGroup.rotation.y = Math.sin(time * 0.5) * 0.3;
    
    // Animation de la queue
    tail.rotation.y = Math.sin(time * 2) * 0.2;
    
    // Animation de la tête
    head.rotation.y = Math.sin(time * 1.5) * 0.1;

    // Animation du Tricératops
    triceraQueueMesh.rotation.y = Math.sin(time * 1.8) * 0.15; // Mouvement de la queue
    triceraHead.rotation.x = Math.sin(time * 1.2) * 0.05; // Léger hochement de tête

    // Clignement des yeux du Tricératops
    const blinkCycle = time % 4; // Un cycle toutes les 4 secondes
    if (blinkCycle < 0.1) { // L'œil reste fermé pendant 0.1s
        triceraEyeLeft.scale.y = 0.1;
        triceraEyeRight.scale.y = 0.1;
    } else {
        triceraEyeLeft.scale.y = 1;
        triceraEyeRight.scale.y = 1;
    }

    // Animation du Stégosaure
    stegoTailEnd.rotation.y = Math.sin(time * 2) * 0.2;
    stegoHead.rotation.x = Math.sin(time * 1.5) * 0.08;
    if (time % 3.5 < 0.1) { // Clignement
        stegoEyeLeft.scale.y = 0.1;
        stegoEyeRight.scale.y = 0.1;
    } else {
        stegoEyeLeft.scale.y = 1;
        stegoEyeRight.scale.y = 1;
    }

    // Animation du Brachiosaure (améliorée)
    // Queue ondulante
    brachioTail.rotation.y = Math.sin(time * 1.5) * 0.15;
    brachioTailMid.rotation.y = Math.sin(time * 1.5 + 0.5) * 0.12;
    brachioTailBase.rotation.y = Math.sin(time * 1.5 + 1) * 0.08;
    
    // Cou fluide (chaque segment bouge légèrement différemment)
    neckSegments.forEach((segment, index) => {
        const offset = index * 0.3;
        segment.rotation.z = -Math.PI / 7 - (index * 0.02) + Math.sin(time * 0.8 + offset) * 0.08;
        segment.rotation.y = Math.sin(time * 0.6 + offset) * 0.04;
    });
    
    // Tête (regarde autour de manière réaliste)
    brachioHead.rotation.x = Math.sin(time * 1.2) * 0.12;
    brachioHead.rotation.y = Math.sin(time * 0.7) * 0.15;
    brachioJaw.rotation.x = Math.abs(Math.sin(time * 0.5)) * 0.08; // Mâchoire qui mâche
    
    // Clignement des yeux
    if (time % 4.5 < 0.1) {
        brachioEyeLeft.scale.y = 0.1;
        brachioEyeRight.scale.y = 0.1;
    } else {
        brachioEyeLeft.scale.y = 1;
        brachioEyeRight.scale.y = 1;
    }
    
    // Mouvement subtil du corps (respiration)
    brachioBody.scale.set(1.5, 1.1 + Math.sin(time * 2) * 0.02, 0.9);

    // Animation du Vélociraptor (améliorée - posture de chasseur)
    // Queue rigide avec léger balancement
    raptorTailSegments.forEach((segment, index) => {
        segment.rotation.y = Math.sin(time * 2 + index * 0.5) * (0.1 - index * 0.02);
    });
    
    // Tête alerte qui regarde autour (chasseur)
    raptorHead.rotation.x = Math.sin(time * 2.5) * 0.15;
    raptorHead.rotation.y = Math.sin(time * 1.8) * 0.2;
    
    // Mâchoire qui s'ouvre (respiration/grognement)
    raptorJaw.rotation.x = Math.abs(Math.sin(time * 3)) * 0.15;
    
    // Cou qui suit les mouvements de la tête
    raptorNeck.rotation.y = Math.sin(time * 1.8) * 0.1;
    
    // Bras qui bougent (griffes prêtes)
    raptorArmLeft.rotation.x = Math.sin(time * 2) * 0.2;
    raptorForearmLeft.rotation.z = Math.PI / 4 + Math.sin(time * 2.2) * 0.15;
    raptorArmRight.rotation.x = Math.sin(time * 2 + Math.PI) * 0.2;
    raptorForearmRight.rotation.z = Math.PI / 4 + Math.sin(time * 2.2 + Math.PI) * 0.15;
    
    // Griffes en faucille qui bougent légèrement
    sickleClawLeft.rotation.z = -Math.PI / 3 + Math.sin(time * 1.5) * 0.1;
    sickleClawRight.rotation.z = -Math.PI / 3 + Math.sin(time * 1.5 + Math.PI) * 0.1;
    
    // Corps qui balance (mouvement de chasseur)
    raptorBody.rotation.z = 0.1 + Math.sin(time * 1.2) * 0.05;
    
    // Clignement rapide (prédateur alerte)
    if (time % 2.5 < 0.08) {
        raptorEyeLeft.scale.y = 0.1;
        raptorEyeRight.scale.y = 0.1;
    } else {
        raptorEyeLeft.scale.y = 1;
        raptorEyeRight.scale.y = 1;
    }

    // Animation de l'Ankylosaure (améliorée - balancement de massue)
    // Queue flexible avec balancement de la massue
    ankyloTail.rotation.y = Math.sin(time * 1.5) * 0.2;
    ankyloTailMidMesh.rotation.y = Math.sin(time * 1.5 + 0.3) * 0.18;
    tailBase1.rotation.y = Math.sin(time * 1.5 + 0.6) * 0.12;
    
    // Massue qui balance (mouvement défensif)
    club.rotation.y = Math.sin(time * 1.5) * 0.3;
    clubBase.rotation.z = Math.sin(time * 1.5) * 0.1;
    clubKnobLeft.rotation.y = Math.sin(time * 1.5) * 0.3;
    clubKnobRight.rotation.y = Math.sin(time * 1.5) * 0.3;
    
    // Tête qui bouge lentement (surveille les menaces)
    ankyloHead.rotation.x = Math.sin(time * 1.3) * 0.06;
    ankyloHead.rotation.y = Math.sin(time * 0.8) * 0.08;
    
    // Respiration (corps qui se soulève légèrement)
    ankyloBody.scale.set(1.3, 0.6 + Math.sin(time * 1.8) * 0.02, 0.9);
    
    // Clignement lent (herbivore calme)
    if (time % 4.2 < 0.12) {
        ankyloEyeLeft.scale.y = 0.1;
        ankyloEyeRight.scale.y = 0.1;
    } else {
        ankyloEyeLeft.scale.y = 1;
        ankyloEyeRight.scale.y = 1;
    }

    // Animation du Ptérodactyle (améliorée - vol planné)
    // Battement d'ailes (coordination réaliste)
    const wingBeat = Math.sin(time * 4);
    pteroWingLeft.rotation.z = wingBeat * 0.6;
    pteroWingRight.rotation.z = wingBeat * 0.6;
    
    // Doigts alaires qui fléchissent avec les ailes
    pteroWingFingerLeft.rotation.z = Math.PI / 2.5 + wingBeat * 0.3;
    pteroWingFingerRight.rotation.z = -Math.PI / 2.5 - wingBeat * 0.3;
    
    // Bras et avant-bras qui suivent le battement
    pteroArmLeft.rotation.z = Math.PI / 3 + wingBeat * 0.2;
    pteroArmRight.rotation.z = -Math.PI / 3 - wingBeat * 0.2;
    pteroForearmLeft.rotation.z = Math.PI / 4 + wingBeat * 0.15;
    pteroForearmRight.rotation.z = -Math.PI / 4 - wingBeat * 0.15;
    
    // Tête qui regarde en bas (cherche des proies)
    pteroHead.rotation.x = Math.sin(time * 2) * 0.15;
    pteroHead.rotation.y = Math.sin(time * 1.5) * 0.1;
    
    // Cou qui s'étire
    pteroNeck.rotation.x = Math.PI / 6 + Math.sin(time * 2) * 0.1;
    
    // Bec qui s'ouvre (cri en vol)
    pteroJaw.rotation.x = Math.PI / 2 + Math.abs(Math.sin(time * 2.5)) * 0.1;
    
    // Corps qui ondule légèrement (vol)
    pteroBody.rotation.x = Math.sin(time * 3) * 0.08;
    pteroBody.position.y = 1.8 + Math.sin(time * 2) * 0.1; // Vol ondulatoire
    
    // Queue qui gouverne
    pteroTail.rotation.y = Math.sin(time * 3.5) * 0.2;
    
    // Crête qui bouge avec le vent
    pteroCrest.rotation.z = Math.sin(time * 4) * 0.05;
    
    // Clignement rapide (vue perçante)
    if (time % 3 < 0.08) {
        pteroEyeLeft.scale.y = 0.1;
        pteroEyeRight.scale.y = 0.1;
    } else {
        pteroEyeLeft.scale.y = 1;
        pteroEyeRight.scale.y = 1;
    }

    // Animation du Spinosaure
    spinoTail.rotation.y = Math.sin(time * 2) * 0.2;
    spinoHead.rotation.x = Math.sin(time * 1.5) * 0.1;
    if (time % 3.8 < 0.1) { // Clignement
        spinoEyeLeft.scale.y = 0.1;
        spinoEyeRight.scale.y = 0.1;
    } else {
        spinoEyeLeft.scale.y = 1;
        spinoEyeRight.scale.y = 1;
    }

    // Animation du Parasaurolophus
    paraTail.rotation.y = Math.sin(time * 1.8) * 0.2;
    paraHead.rotation.x = Math.sin(time * 1.3) * 0.08;
    if (time % 4.8 < 0.1) { // Clignement
        paraEyeLeft.scale.y = 0.1;
        paraEyeRight.scale.y = 0.1;
    } else {
        paraEyeLeft.scale.y = 1;
        paraEyeRight.scale.y = 1;
    }
    
    // controls.update();
    renderer.render(scene, camera);
}

animate();

// Gestion du redimensionnement
window.addEventListener('resize', () => {
    camera.aspect = 800 / 750;
    camera.updateProjectionMatrix();
    renderer.setSize(800, 750);
});