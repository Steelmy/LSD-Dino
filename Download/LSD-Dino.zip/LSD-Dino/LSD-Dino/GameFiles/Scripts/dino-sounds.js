// Fonction pour jouer un son au survol des dinos
document.addEventListener('DOMContentLoaded', function() {
    // Sélectionner tous les dinos
    const dinos = document.querySelectorAll('.side-dino');
    
    // Pré-charger les sons
    const hoverSound = new Audio('../audio/dinosaur-yee.mp3');
    const clickSound = new Audio('../audio/man-dinosaur-scream.mp3');
    const titleSound = new Audio('../audio/yeah-boiii-i-i-i.mp3'); // REMPLACEZ par le nom de votre fichier
    hoverSound.volume = 0.5;
    clickSound.volume = 0.6;
    titleSound.volume = 0.7;
    
    // Variable pour savoir si l'audio est débloqué
    let audioUnlocked = false;
    
    // Débloquer l'audio au premier clic sur la page
    function unlockAudio() {
        if (!audioUnlocked) {
            hoverSound.play().then(() => {
                hoverSound.pause();
                hoverSound.currentTime = 0;
            }).catch(() => {});
            
            clickSound.play().then(() => {
                clickSound.pause();
                clickSound.currentTime = 0;
            }).catch(() => {});
            
            titleSound.play().then(() => {
                titleSound.pause();
                titleSound.currentTime = 0;
            }).catch(() => {});
            
            audioUnlocked = true;
            document.removeEventListener('click', unlockAudio);
        }
    }
    
    document.addEventListener('click', unlockAudio);
    
    // Son au survol
    function playSound() {
        hoverSound.currentTime = 0;
        hoverSound.play().catch(err => console.log('Erreur audio hover:', err));
    }
    
    // Son au clic
    function playClickSound() {
        clickSound.currentTime = 0;
        clickSound.play().catch(err => console.log('Erreur audio clic:', err));
    }
    
    // Ajouter les événements hover et clic à chaque dino
    dinos.forEach(dino => {
        dino.addEventListener('mouseenter', playSound);
        dino.addEventListener('click', playClickSound);
    });
    
    // Mode accélération au survol du titre + son
    const title = document.querySelector('.dino-header h1');
    
    if (title) {
        title.addEventListener('mouseenter', function() {
            document.body.classList.add('speed-mode');
            // Jouer le son du titre
            titleSound.currentTime = 0;
            titleSound.play().catch(err => console.log('Erreur audio titre:', err));
        });
        
        title.addEventListener('mouseleave', function() {
            document.body.classList.remove('speed-mode');
            // Arrêter le son du titre
            titleSound.pause();
            titleSound.currentTime = 0;
        });
    }
});
