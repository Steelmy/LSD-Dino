/*
 * Script d'activation audio pour les menus
 * Active l'audio dès qu'on clique sur les liens de navigation
 */

// Fonction pour activer l'audio sur les clics de navigation
function enableAudioOnNavigation() {
    // Marquer l'interaction utilisateur
    sessionStorage.setItem('audioInteractionEnabled', 'true');
    console.log('🎵 Navigation - Audio pré-autorisé pour les pages suivantes');
}

// Activer l'audio sur tous les liens de navigation
document.addEventListener('DOMContentLoaded', () => {
    // Sélectionner tous les liens de navigation
    const navLinks = document.querySelectorAll('a[href*=".html"], .nav-link, .menu-item, .btn-mode');
    
    navLinks.forEach(link => {
        link.addEventListener('click', enableAudioOnNavigation);
    });
    
    // Aussi sur les boutons de mode de jeu
    const modeButtons = document.querySelectorAll('button[onclick*="window.location"]');
    modeButtons.forEach(button => {
        button.addEventListener('click', enableAudioOnNavigation);
    });
    
    console.log(`🎵 Audio-enabler activé sur ${navLinks.length + modeButtons.length} éléments de navigation`);
});

// Activer aussi sur n'importe quel clic dans les menus
document.addEventListener('click', (event) => {
    // Si on est sur une page de menu (index, mode-de-jeu)
    if (window.location.pathname.includes('index') || 
        window.location.pathname.includes('mode-de-jeu') ||
        window.location.pathname.includes('menu')) {
        
        enableAudioOnNavigation();
    }
});

// Export pour utilisation externe
window.enableAudioOnNavigation = enableAudioOnNavigation;
