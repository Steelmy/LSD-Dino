// === TABLEAU DE CORRESPONDANCE DINOSAURES <-> BOUTONS ===
const dinosaurs = [
    { name: 'T-Rex', group: trexGroup, index: 0 },
    { name: 'Tricératops', group: triceratopsGroup, index: 1 },
    { name: 'Stégosaure', group: stegosaurusGroup, index: 2 },
    { name: 'Brachiosaure', group: brachiosaurusGroup, index: 3 },
    { name: 'Vélociraptor', group: velociraptorGroup, index: 4 },
    { name: 'Ankylosaure', group: ankylosaurusGroup, index: 5 },
    { name: 'Ptérodactyle', group: pterodactylGroup, index: 6 },
    { name: 'Spinosaure', group: spinosaurusGroup, index: 7 },
    { name: 'Parasaurolophus', group: parasaurolophusGroup, index: 8 }
];

// === SYSTÈME DE POINTS ET SCORES ===
let score = 0;
const scoreElement = document.getElementById('score-value');

function updateScore(points) {
    score += points;
    // S'assure que le score ne descend jamais en dessous de 0
    if (score < 0) {
        score = 0;
    }
    scoreElement.textContent = score;
    
    // Animation du score (différente selon si on gagne ou perd des points)
    if (points > 0) {
        scoreElement.style.transform = 'scale(1.3)';
        scoreElement.style.color = '#4CAF50'; // Vert pour les points gagnés
    } else if (points < 0) {
        scoreElement.style.transform = 'scale(0.8)';
        scoreElement.style.color = '#f44336'; // Rouge pour les points perdus
    }
    
    setTimeout(() => {
        scoreElement.style.transform = 'scale(1)';
        scoreElement.style.color = '#333'; // Retour à la couleur normale
    }, 200);
}

// === SYSTÈME DE SAUVEGARDE DES SCORES ===
function getHighScores() {
    const scores = localStorage.getItem('lsd-dino-scores');
    return scores ? JSON.parse(scores) : [];
}

function saveScore(playerScore) {
    const scores = getHighScores();
    const now = new Date();
    const scoreEntry = {
        score: playerScore,
        date: now.toLocaleDateString('fr-FR'),
        time: now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })
    };
    
    scores.push(scoreEntry);
    scores.sort((a, b) => b.score - a.score); // Trie par score décroissant
    scores.splice(10); // Garde seulement les 10 meilleurs scores
    
    localStorage.setItem('lsd-dino-scores', JSON.stringify(scores));
    return scores;
}

function showHighScores() {
    const scores = getHighScores();
    
    // Crée ou met à jour la modal des scores
    let modal = document.getElementById('scores-modal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'scores-modal';
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(0, 0, 0, 0.8);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 10000;
            opacity: 0;
            transition: opacity 0.3s ease;
        `;
        document.body.appendChild(modal);
    }
    
    modal.innerHTML = `
        <div style="
            background: linear-gradient(135deg, #ffffff 0%, #f0f0f0 100%);
            border: 4px solid #333;
            border-radius: 20px;
            padding: 30px;
            max-width: 500px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
            box-shadow: 0 10px 0 #333, 0 15px 30px rgba(0, 0, 0, 0.5);
            text-align: center;
        ">
            <h2 style="
                font-size: 2.5em;
                margin-bottom: 20px;
                background: linear-gradient(90deg, #ff0055, #ff9900, #ffee00, #33dd66, #00aaff, #8855ff, #ff0055);
                background-size: 200% 200%;
                -webkit-background-clip: text;
                background-clip: text;
                -webkit-text-fill-color: transparent;
                -webkit-text-stroke: 1px #333;
                animation: gradientShift 2s ease infinite;
            ">🏆 MEILLEURS SCORES 🏆</h2>
            
            <div style="margin-bottom: 25px;">
                ${scores.length === 0 ? 
                    '<p style="font-size: 1.2em; color: #666;">Aucun score enregistré</p>' :
                    scores.map((entry, index) => `
                        <div style="
                            display: flex;
                            justify-content: space-between;
                            align-items: center;
                            padding: 10px 15px;
                            margin: 8px 0;
                            background: ${index < 3 ? 
                                (index === 0 ? 'linear-gradient(90deg, #ffd700, #ffed4e)' :
                                 index === 1 ? 'linear-gradient(90deg, #c0c0c0, #e8e8e8)' :
                                 'linear-gradient(90deg, #cd7f32, #daa520)') :
                                '#f9f9f9'};
                            border: 2px solid #333;
                            border-radius: 10px;
                            font-weight: bold;
                            color: #333;
                        ">
                            <span style="font-size: 1.3em;">
                                ${index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `${index + 1}.`}
                            </span>
                            <span style="font-size: 1.5em;">${entry.score} pts</span>
                            <span style="font-size: 0.9em; opacity: 0.8;">
                                ${entry.date}<br>${entry.time}
                            </span>
                        </div>
                    `).join('')
                }
            </div>
            
            <div style="display: flex; gap: 15px; justify-content: center;">
                <button onclick="closeScoresModal()" style="
                    background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%);
                    border: 3px solid #333;
                    border-radius: 10px;
                    padding: 12px 25px;
                    font-size: 1.2em;
                    font-weight: bold;
                    color: white;
                    cursor: pointer;
                    box-shadow: 0 4px 0 #333;
                    transition: transform 0.1s ease;
                " onmousedown="this.style.transform='translateY(2px)'; this.style.boxShadow='0 2px 0 #333';"
                   onmouseup="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 0 #333';"
                   onmouseleave="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 0 #333';">
                    FERMER
                </button>
                ${scores.length > 0 ? `
                <button onclick="clearAllScores()" style="
                    background: linear-gradient(135deg, #f44336 0%, #d32f2f 100%);
                    border: 3px solid #333;
                    border-radius: 10px;
                    padding: 12px 25px;
                    font-size: 1.2em;
                    font-weight: bold;
                    color: white;
                    cursor: pointer;
                    box-shadow: 0 4px 0 #333;
                    transition: transform 0.1s ease;
                " onmousedown="this.style.transform='translateY(2px)'; this.style.boxShadow='0 2px 0 #333';"
                   onmouseup="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 0 #333';"
                   onmouseleave="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 0 #333';">
                    🗑️ EFFACER
                </button>
                ` : ''}
            </div>
        </div>
    `;
    
    // Affiche la modal avec animation
    modal.style.display = 'flex';
    setTimeout(() => {
        modal.style.opacity = '1';
    }, 10);
}

function closeScoresModal() {
    const modal = document.getElementById('scores-modal');
    if (modal) {
        modal.style.opacity = '0';
        setTimeout(() => {
            modal.style.display = 'none';
            // Réaffiche la modal de fin de partie SEULEMENT si le jeu n'est pas actif
            const endGameModal = document.getElementById('endgame-modal');
            if (endGameModal && !gameActive) {
                endGameModal.style.display = 'flex';
                setTimeout(() => {
                    endGameModal.style.opacity = '1';
                }, 10);
            }
        }, 300);
    }
}

function clearAllScores() {
    if (confirm('Êtes-vous sûr de vouloir effacer tous les scores ?')) {
        localStorage.removeItem('lsd-dino-scores');
        closeScoresModal();
        setTimeout(() => {
            showHighScores(); // Réaffiche la modal vide
        }, 300);
    }
}

// Fonctions globales (accessibles depuis le HTML)
window.closeScoresModal = closeScoresModal;
window.showHighScores = showHighScores;
window.clearAllScores = clearAllScores;
window.closeEndGameModal = closeEndGameModal;
window.restartGame = restartGame;

// === SYSTÈME DE JEU ===
let currentDino = null;
let blinkInterval = null;
let gameActive = false;
let gameTimer = null;
let gameTimeLeft = 60; // 1 minute en secondes
let dinoTimer = null; // Timer pour chaque dinosaure (5 secondes max)
let originalMaterials = new Map(); // Stocke les matériaux originaux
let currentEventType = null; // 'blink' ou 'glow' - type d'événement actuel

// Fonction pour appliquer l'effet d'illumination jaune
function applyYellowGlow(dino) {
    // Sauvegarde les matériaux originaux si pas déjà fait
    if (!originalMaterials.has(dino.name)) {
        const materials = [];
        dino.group.traverse((child) => {
            if (child.isMesh && child.material) {
                materials.push({
                    mesh: child,
                    originalMaterial: child.material.clone()
                });
            }
        });
        originalMaterials.set(dino.name, materials);
    }
    
    // Applique l'effet jaune lumineux
    dino.group.traverse((child) => {
        if (child.isMesh && child.material) {
            child.material.emissive.setHex(0xffff00); // Jaune lumineux
            child.material.emissiveIntensity = 0.5;
            child.material.color.setHex(0xffff88); // Teinte jaune
        }
    });
}

// Fonction pour restaurer l'apparence originale
function restoreOriginalAppearance(dino) {
    const materials = originalMaterials.get(dino.name);
    if (materials) {
        materials.forEach(({ mesh, originalMaterial }) => {
            mesh.material.emissive.copy(originalMaterial.emissive);
            mesh.material.emissiveIntensity = originalMaterial.emissiveIntensity;
            mesh.material.color.copy(originalMaterial.color);
        });
    }
}

// Fonction pour faire clignoter un dinosaure (disparition/apparition)
function startBlinking(dino) {
    let isVisible = true;
    
    blinkInterval = setInterval(() => {
        if (isVisible) {
            dino.group.visible = false;
        } else {
            dino.group.visible = true;
        }
        isVisible = !isVisible;
    }, 300); // Clignote toutes les 300ms
}

// Fonction pour faire briller un dinosaure en jaune
function startGlowing(dino) {
    let isGlowing = true;
    
    // Applique immédiatement l'effet jaune
    applyYellowGlow(dino);
    
    blinkInterval = setInterval(() => {
        if (isGlowing) {
            restoreOriginalAppearance(dino);
        } else {
            applyYellowGlow(dino);
        }
        isGlowing = !isGlowing;
    }, 300); // Clignote toutes les 300ms
}

// Fonction pour démarrer un événement aléatoire
function startRandomEvent(dino) {
    // Choisit aléatoirement entre clignotement et illumination (50/50)
    const eventTypes = ['blink', 'glow'];
    currentEventType = eventTypes[Math.floor(Math.random() * eventTypes.length)];
    
    console.log('Événement sélectionné:', currentEventType, 'pour', dino.name);
    
    if (currentEventType === 'blink') {
        startBlinking(dino);
    } else {
        startGlowing(dino);
    }
}

// Fonction pour arrêter le clignotement
function stopBlinking() {
    if (blinkInterval) {
        clearInterval(blinkInterval);
        blinkInterval = null;
    }
    
    // Arrête le timer du dinosaure
    if (dinoTimer) {
        clearTimeout(dinoTimer);
        dinoTimer = null;
    }
    
    // Restaure l'apparence de tous les dinosaures
    dinosaurs.forEach(dino => {
        dino.group.visible = true;
        restoreOriginalAppearance(dino);
    });
}

// === SYSTÈME DE TIMER ===
function updateTimerDisplay() {
    const minutes = Math.floor(gameTimeLeft / 60);
    const seconds = gameTimeLeft % 60;
    const timeString = `${minutes}:${seconds.toString().padStart(2, '0')}`;
    
    // Cherche l'élément timer ou le crée s'il n'existe pas
    let timerElement = document.getElementById('game-timer');
    if (!timerElement) {
        timerElement = document.createElement('div');
        timerElement.id = 'game-timer';
        timerElement.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: linear-gradient(135deg, #ffffff 0%, #f0f0f0 100%);
            border: 3px solid #333;
            border-radius: 15px;
            padding: 15px 25px;
            font-size: 2em;
            font-weight: bold;
            color: #333;
            z-index: 1000;
            box-shadow: 0 6px 0 #333, 0 8px 15px rgba(0, 0, 0, 0.3);
            text-align: center;
            min-width: 120px;
        `;
        document.body.appendChild(timerElement);
    }
    
    timerElement.textContent = timeString;
    
    // Change la couleur quand il reste moins de 10 secondes
    if (gameTimeLeft <= 10) {
        timerElement.style.background = 'linear-gradient(135deg, #ff6b6b 0%, #ff5252 100%)';
        timerElement.style.color = 'white';
        timerElement.style.animation = 'pulse 0.5s ease-in-out infinite alternate';
    }
}

function startGameTimer() {
    updateTimerDisplay();
    
    gameTimer = setInterval(() => {
        gameTimeLeft--;
        updateTimerDisplay();
        
        if (gameTimeLeft <= 0) {
            endGame();
        }
    }, 1000);
}

function endGame() {
    gameActive = false;
    stopBlinking();
    
    if (gameTimer) {
        clearInterval(gameTimer);
        gameTimer = null;
    }
    
    // Arrêter la musique
    if (window.audioManager) {
        window.audioManager.stopGameMusic();
    }
    
    // Sauvegarde le score
    const updatedScores = saveScore(score);
    const isNewRecord = updatedScores[0].score === score;
    
    // Affiche la modal de fin de jeu
    showEndGameModal(isNewRecord);
}

function showEndGameModal(isNewRecord) {
    // Crée la modal de fin de jeu
    let modal = document.getElementById('endgame-modal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'endgame-modal';
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(0, 0, 0, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 10001;
            opacity: 0;
            transition: opacity 0.3s ease;
        `;
        document.body.appendChild(modal);
    }
    
    modal.innerHTML = `
        <div style="
            background: linear-gradient(135deg, #ffffff 0%, #f0f0f0 100%);
            border: 4px solid #333;
            border-radius: 20px;
            padding: 40px;
            max-width: 600px;
            width: 90%;
            text-align: center;
            box-shadow: 0 15px 0 #333, 0 20px 40px rgba(0, 0, 0, 0.6);
        ">
            <h2 style="
                font-size: 3em;
                margin-bottom: 20px;
                background: linear-gradient(90deg, #ff0055, #ff9900, #ffee00, #33dd66, #00aaff, #8855ff, #ff0055);
                background-size: 200% 200%;
                -webkit-background-clip: text;
                background-clip: text;
                -webkit-text-fill-color: transparent;
                -webkit-text-stroke: 2px #333;
                animation: gradientShift 2s ease infinite;
            ">${isNewRecord ? '🎉 NOUVEAU RECORD ! 🎉' : '⏰ TEMPS ÉCOULÉ !'}</h2>
            
            <div style="
                font-size: 2.5em;
                font-weight: bold;
                color: #333;
                margin: 30px 0;
                background: linear-gradient(90deg, #ff0055, #ff9900, #ffee00, #33dd66, #00aaff, #8855ff, #ff0055);
                background-size: 200% 200%;
                -webkit-background-clip: text;
                background-clip: text;
                -webkit-text-fill-color: transparent;
                -webkit-text-stroke: 1px #333;
                animation: gradientShift 2s ease infinite;
            ">SCORE : ${score} POINTS</div>
            
            <div style="display: flex; gap: 20px; justify-content: center; margin-top: 40px;">
                <button onclick="restartGame(); closeEndGameModal();" style="
                    background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%);
                    border: none;
                    border-radius: 15px;
                    padding: 15px 30px;
                    font-size: 1.5em;
                    font-weight: bold;
                    color: white;
                    cursor: pointer;
                    box-shadow: 0 6px 0 #2e7d32, 0 8px 20px rgba(0, 0, 0, 0.3);
                    transition: transform 0.1s ease;
                    -webkit-text-stroke: 1px rgba(0,0,0,0.3);
                " onmousedown="this.style.transform='translateY(3px)'; this.style.boxShadow='0 3px 0 #2e7d32, 0 5px 15px rgba(0, 0, 0, 0.3)';"
                   onmouseup="this.style.transform='translateY(0)'; this.style.boxShadow='0 6px 0 #2e7d32, 0 8px 20px rgba(0, 0, 0, 0.3)';"
                   onmouseleave="this.style.transform='translateY(0)'; this.style.boxShadow='0 6px 0 #2e7d32, 0 8px 20px rgba(0, 0, 0, 0.3)';">
                    🔄 REJOUER
                </button>
                
                <button onclick="showHighScores(); closeEndGameModal();" style="
                    background: linear-gradient(135deg, #2196F3 0%, #1976D2 100%);
                    border: none;
                    border-radius: 15px;
                    padding: 15px 30px;
                    font-size: 1.5em;
                    font-weight: bold;
                    color: white;
                    cursor: pointer;
                    box-shadow: 0 6px 0 #1565C0, 0 8px 20px rgba(0, 0, 0, 0.3);
                    transition: transform 0.1s ease;
                    -webkit-text-stroke: 1px rgba(0,0,0,0.3);
                " onmousedown="this.style.transform='translateY(3px)'; this.style.boxShadow='0 3px 0 #1565C0, 0 5px 15px rgba(0, 0, 0, 0.3)';"
                   onmouseup="this.style.transform='translateY(0)'; this.style.boxShadow='0 6px 0 #1565C0, 0 8px 20px rgba(0, 0, 0, 0.3)';"
                   onmouseleave="this.style.transform='translateY(0)'; this.style.boxShadow='0 6px 0 #1565C0, 0 8px 20px rgba(0, 0, 0, 0.3)';">
                    🏆 SCORES
                </button>
                
                <button onclick="window.location.href='../../LSD-Dino.html';" style="
                    background: linear-gradient(135deg, #ff9800 0%, #f57c00 100%);
                    border: none;
                    border-radius: 15px;
                    padding: 15px 30px;
                    font-size: 1.5em;
                    font-weight: bold;
                    color: white;
                    cursor: pointer;
                    box-shadow: 0 6px 0 #ef6c00, 0 8px 20px rgba(0, 0, 0, 0.3);
                    transition: transform 0.1s ease;
                    -webkit-text-stroke: 1px rgba(0,0,0,0.3);
                " onmousedown="this.style.transform='translateY(3px)'; this.style.boxShadow='0 3px 0 #ef6c00, 0 5px 15px rgba(0, 0, 0, 0.3)';"
                   onmouseup="this.style.transform='translateY(0)'; this.style.boxShadow='0 6px 0 #ef6c00, 0 8px 20px rgba(0, 0, 0, 0.3)';"
                   onmouseleave="this.style.transform='translateY(0)'; this.style.boxShadow='0 6px 0 #ef6c00, 0 8px 20px rgba(0, 0, 0, 0.3)';">
                    🏠 MENU
                </button>
            </div>
        </div>
    `;
    
    // Affiche la modal avec animation
    modal.style.display = 'flex';
    setTimeout(() => {
        modal.style.opacity = '1';
    }, 10);
}

function closeEndGameModal() {
    const modal = document.getElementById('endgame-modal');
    if (modal) {
        modal.style.opacity = '0';
        setTimeout(() => {
            modal.style.display = 'none';
        }, 300);
    }
}

function restartGame() {
    score = 0;
    gameTimeLeft = 60;
    scoreElement.textContent = score;
    gameActive = true;
    selectRandomDino();
    startGameTimer();
    
    // Redémarrer la musique
    if (window.audioManager) {
        window.audioManager.startGameMusic("CLASSIQUE");
    }
}

// Fonction pour choisir un nouveau dinosaure aléatoire
function selectRandomDino() {
    if (!gameActive) return;
    
    stopBlinking();
    
    // Choisit un dinosaure aléatoire
    const randomIndex = Math.floor(Math.random() * dinosaurs.length);
    currentDino = dinosaurs[randomIndex];
    
    console.log('Dinosaure sélectionné:', currentDino.name);
    
    // Lance un événement aléatoire
    startRandomEvent(currentDino);
    
    // Démarre le timer de 3 secondes pour ce dinosaure
    dinoTimer = setTimeout(() => {
        if (gameActive && currentDino) {
            // Temps écoulé ! Pénalité
            updateScore(-1);
            console.log('Temps écoulé pour:', currentDino.name);
            
            // Effet visuel d'échec sur tous les boutons
            const buttons = document.querySelectorAll('.btn-circle');
            buttons.forEach(button => {
                button.style.background = '#ff6b6b';
                setTimeout(() => {
                    button.style.background = '#fff';
                }, 500);
            });
            
            // Sélectionne un nouveau dinosaure
            setTimeout(() => {
                selectRandomDino();
            }, 600);
        }
    }, 3000); // 3 secondes maximum
}

// Gestion des clics sur les boutons
const dinoButtons = document.querySelectorAll('.btn-circle');
dinoButtons.forEach((button, index) => {
    button.addEventListener('click', () => {
        if (!gameActive || !currentDino) return;
        
        // Animation du bouton
        button.style.transform = 'scale(0.9)';
        setTimeout(() => {
            button.style.transform = 'scale(1)';
        }, 100);
        
        // Arrête le timer du dinosaure actuel
        if (dinoTimer) {
            clearTimeout(dinoTimer);
            dinoTimer = null;
        }
        
        // Vérifie si c'est le bon bouton
        if (index === currentDino.index) {
            // BON BOUTON !
            updateScore(1);
            
            // Effet visuel de succès
            button.style.background = '#4CAF50';
            setTimeout(() => {
                button.style.background = '#fff';
            }, 300);
            
            // Sélectionne un nouveau dinosaure après un court délai
            setTimeout(() => {
                selectRandomDino();
            }, 500);
        } else {
            // MAUVAIS BOUTON
            updateScore(-1); // Perd un point
            
            // Effet visuel d'erreur
            button.style.background = '#f44336';
            setTimeout(() => {
                button.style.background = '#fff';
            }, 300);
            
            // Continue avec le même dinosaure (pas de nouveau dinosaure)
        }
    });
});

// Démarre le jeu après le timer de 3 secondes
setTimeout(() => {
    gameActive = true;
    selectRandomDino();
    startGameTimer();
    
    // Démarrer la musique du mode classique
    if (window.audioManager) {
        window.audioManager.startGameMusic("CLASSIQUE");
    }
}, 3000);
