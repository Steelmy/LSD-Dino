// Détection du mode en premier
const urlParams = new URLSearchParams(window.location.search);
const gameMode = urlParams.get('mode') || 'normal';
const isHardcoreMode = gameMode === 'hardcore';
const isChaosMode = gameMode === 'chaos';

// === SYSTÈME DE POINTS ET SCORES ===
let score = 0;
const scoreElement = document.getElementById('score-value');

function updateScore(points) {
    score += points;
    // S'assure que le score ne descend jamais en dessous de 0
    if (score < 0) {
        score = 0;
    }
    scoreElement.textContent = score;
    window.score = score; // Sync global
    
    // Animation du score (différente selon si on gagne ou perd des points)
    if (points > 0) {
        scoreElement.style.transform = 'scale(1.3)';
        scoreElement.style.color = '#4CAF50'; // Vert pour les points gagnés
    } else if (points < 0) {
        scoreElement.style.transform = 'scale(0.8)';
        scoreElement.style.color = '#f44336'; // Rouge pour les points perdus
    }
    
    setTimeout(() => {
        scoreElement.style.transform = 'scale(1)';
        scoreElement.style.color = '#333'; // Retour à la couleur normale
    }, 200);
}

// === SYSTÈME DE SAUVEGARDE DES SCORES ===
function getHighScores() {
    const scores = localStorage.getItem('lsd-dino-hunt-scores');
    return scores ? JSON.parse(scores) : [];
}

function saveScore(playerScore) {
    const scores = getHighScores();
    const now = new Date();
    const scoreEntry = {
        score: playerScore,
        date: now.toLocaleDateString('fr-FR'),
        time: now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })
    };
    
    scores.push(scoreEntry);
    scores.sort((a, b) => b.score - a.score); // Trie par score décroissant
    scores.splice(10); // Garde seulement les 10 meilleurs scores
    
    localStorage.setItem('lsd-dino-hunt-scores', JSON.stringify(scores));
    return scores;
}

function showHighScores() {
    const scores = getHighScores();
    
    // Crée ou met à jour la modal des scores
    let modal = document.getElementById('scores-modal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'scores-modal';
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(0, 0, 0, 0.8);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 10000;
            opacity: 0;
            transition: opacity 0.3s ease;
        `;
        document.body.appendChild(modal);
    }
    
    modal.innerHTML = `
        <div style="
            background: linear-gradient(135deg, #ffffff 0%, #f0f0f0 100%);
            border: 4px solid #333;
            border-radius: 20px;
            padding: 30px;
            max-width: 500px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
            box-shadow: 0 10px 0 #333, 0 15px 30px rgba(0, 0, 0, 0.5);
            text-align: center;
        ">
            <h2 style="
                font-size: 2.5em;
                margin-bottom: 20px;
                background: linear-gradient(90deg, #ff0055, #ff9900, #ffee00, #33dd66, #00aaff, #8855ff, #ff0055);
                background-size: 200% 200%;
                -webkit-background-clip: text;
                background-clip: text;
                -webkit-text-fill-color: transparent;
                -webkit-text-stroke: 1px #333;
                animation: gradientShift 2s ease infinite;
            ">🏆 MEILLEURS SCORES - CHASSE ${isHardcoreMode ? 'HARDCORE 💀' : (isChaosMode ? 'CHAOS 🌪️' : '')} 🏆</h2>
            
            <div style="margin-bottom: 25px;">
                ${scores.length === 0 ? 
                    '<p style="font-size: 1.2em; color: #666;">Aucun score enregistré</p>' :
                    scores.map((entry, index) => `
                        <div style="
                            display: flex;
                            justify-content: space-between;
                            align-items: center;
                            padding: 10px 15px;
                            margin: 8px 0;
                            background: ${index < 3 ? 
                                (index === 0 ? 'linear-gradient(90deg, #ffd700, #ffed4e)' :
                                 index === 1 ? 'linear-gradient(90deg, #c0c0c0, #e8e8e8)' :
                                 'linear-gradient(90deg, #cd7f32, #daa520)') :
                                '#f9f9f9'};
                            border: 2px solid #333;
                            border-radius: 10px;
                            font-weight: bold;
                            color: #333;
                        ">
                            <span style="font-size: 1.3em;">
                                ${index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `${index + 1}.`}
                            </span>
                            <span style="font-size: 1.5em;">${entry.score} pts</span>
                            <span style="font-size: 0.9em; opacity: 0.8;">
                                ${entry.date}<br>${entry.time}
                            </span>
                        </div>
                    `).join('')
                }
            </div>
            
            <div style="display: flex; gap: 15px; justify-content: center;">
                <button onclick="closeScoresModal()" style="
                    background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%);
                    border: 3px solid #333;
                    border-radius: 10px;
                    padding: 12px 25px;
                    font-size: 1.2em;
                    font-weight: bold;
                    color: white;
                    cursor: pointer;
                    box-shadow: 0 4px 0 #333;
                    transition: transform 0.1s ease;
                " onmousedown="this.style.transform='translateY(2px)'; this.style.boxShadow='0 2px 0 #333';"
                   onmouseup="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 0 #333';"
                   onmouseleave="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 0 #333';">
                    FERMER
                </button>
                ${scores.length > 0 ? `
                <button onclick="clearAllScores()" style="
                    background: linear-gradient(135deg, #f44336 0%, #d32f2f 100%);
                    border: 3px solid #333;
                    border-radius: 10px;
                    padding: 12px 25px;
                    font-size: 1.2em;
                    font-weight: bold;
                    color: white;
                    cursor: pointer;
                    box-shadow: 0 4px 0 #333;
                    transition: transform 0.1s ease;
                " onmousedown="this.style.transform='translateY(2px)'; this.style.boxShadow='0 2px 0 #333';"
                   onmouseup="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 0 #333';"
                   onmouseleave="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 0 #333';">
                    🗑️ EFFACER
                </button>
                ` : ''}
            </div>
        </div>
    `;
    
    // Affiche la modal avec animation
    modal.style.display = 'flex';
    setTimeout(() => {
        modal.style.opacity = '1';
    }, 10);
}

function closeScoresModal() {
    const modal = document.getElementById('scores-modal');
    if (modal) {
        modal.style.opacity = '0';
        setTimeout(() => {
            modal.style.display = 'none';
            // Réaffiche la modal de fin de partie SEULEMENT si le jeu n'est pas actif
            const endGameModal = document.getElementById('endgame-modal');
            if (endGameModal && !gameActive) {
                endGameModal.style.display = 'flex';
                setTimeout(() => {
                    endGameModal.style.opacity = '1';
                }, 10);
            }
        }, 300);
    }
}

function clearAllScores() {
    if (confirm('Êtes-vous sûr de vouloir effacer tous les scores ?')) {
        localStorage.removeItem('lsd-dino-hunt-scores');
        closeScoresModal();
        setTimeout(() => {
            showHighScores(); // Réaffiche la modal vide
        }, 300);
    }
}

// === SYSTÈME DE JEU ===
let gameActive = false;
let gameTimer = null;
let gameTimeLeft = isHardcoreMode ? 30 : (isChaosMode ? 45 : 60); // 30s Hardcore, 45s Chaos, 60s Normal

// Variables globales optimisées pour Arduino (score uniquement)
window.score = score;
let spawnInterval = null;
let activeDinos = [];

// Configuration selon le mode
const gameConfig = isHardcoreMode ? {
    spawnRate: 400, // Spawn toutes les 400ms (ultra rapide)
    dinoLifeTime: { min: 800, max: 1500 }, // Durée de vie 0.8-1.5s (très court)
    maxDinos: 12, // Maximum 12 dinos simultanés
    spawnVariation: 200 // Variation de 200ms
} : isChaosMode ? {
    spawnRate: 200, // Spawn toutes les 200ms (CHAOS!)
    dinoLifeTime: { min: 1000, max: 2000 }, // Durée de vie 1-2s (court)
    maxDinos: 15, // Maximum 15 dinos simultanés (CHAOS!)
    spawnVariation: 100 // Variation de 100ms (très prévisible)
} : {
    spawnRate: 700, // Spawn toutes les 700ms (normal)
    dinoLifeTime: { min: 2000, max: 4000 }, // Durée de vie 2-4s (normal)
    maxDinos: 8, // Maximum 8 dinos simultanés
    spawnVariation: 500 // Variation de 500ms
};

// Liste des emojis de dinosaures
const dinoEmojis = ['🦕', '🦖', '🦴', '🐲', '🐉'];

// === SYSTÈME DE TIMER ===
function updateTimerDisplay() {
    const minutes = Math.floor(gameTimeLeft / 60);
    const seconds = gameTimeLeft % 60;
    const timeString = `${minutes}:${seconds.toString().padStart(2, '0')}`;
    
    // Cherche l'élément timer ou le crée s'il n'existe pas
    let timerElement = document.getElementById('game-timer');
    if (!timerElement) {
        timerElement = document.createElement('div');
        timerElement.id = 'game-timer';
        document.body.appendChild(timerElement);
    }
    
    timerElement.textContent = timeString;
    
    // Change la couleur quand il reste moins de 10 secondes
    if (gameTimeLeft <= 10) {
        timerElement.style.background = 'linear-gradient(135deg, #ff6b6b 0%, #ff5252 100%)';
        timerElement.style.color = 'white';
        timerElement.style.animation = 'pulse 0.5s ease-in-out infinite alternate';
    }
}

function startGameTimer() {
    updateTimerDisplay();
    
    gameTimer = setInterval(() => {
        gameTimeLeft--;
        updateTimerDisplay();
        
        if (gameTimeLeft <= 0) {
            endGame();
        }
    }, 1000);
}

// === SYSTÈME DE SPAWN DES DINOSAURES ===
function getRandomPosition() {
    const gameArea = document.getElementById('game-area');
    const rect = gameArea.getBoundingClientRect();
    
    // Marges pour éviter que les dinos apparaissent trop près des bords
    const margin = 100;
    const maxX = window.innerWidth - margin - 80; // 80 = taille du dino
    const maxY = window.innerHeight - margin - 80 - 120; // 120 = header height
    
    return {
        x: Math.random() * (maxX - margin) + margin,
        y: Math.random() * (maxY - margin) + margin + 120 // +120 pour le header
    };
}

function spawnDino() {
    if (!gameActive) return;
    
    const dino = document.createElement('div');
    dino.className = isHardcoreMode ? 'hunt-dino hardcore' : (isChaosMode ? 'hunt-dino chaos' : 'hunt-dino');
    dino.textContent = dinoEmojis[Math.floor(Math.random() * dinoEmojis.length)];
    
    const position = getRandomPosition();
    dino.style.left = position.x + 'px';
    dino.style.top = position.y + 'px';
    
    // Durée de vie du dinosaure selon le mode
    const lifeTime = gameConfig.dinoLifeTime.min + Math.random() * (gameConfig.dinoLifeTime.max - gameConfig.dinoLifeTime.min);
    
    // Ajoute le dinosaure à la page
    document.body.appendChild(dino);
    activeDinos.push(dino);
    
    // Gestion du clic
    dino.addEventListener('click', () => {
        if (!gameActive) return;
        
        // Animation de succès
        dino.className = 'hunt-dino success';
        updateScore(1);
        
        // Retire le dino de la liste active
        const index = activeDinos.indexOf(dino);
        if (index > -1) {
            activeDinos.splice(index, 1);
        }
        
        // Supprime l'élément après l'animation
        setTimeout(() => {
            if (dino.parentNode) {
                dino.parentNode.removeChild(dino);
            }
        }, 500);
    });
    
    // Disparition automatique après la durée de vie
    setTimeout(() => {
        if (dino.parentNode && activeDinos.includes(dino)) {
            dino.className = 'hunt-dino disappearing';
            
            // Retire de la liste active
            const index = activeDinos.indexOf(dino);
            if (index > -1) {
                activeDinos.splice(index, 1);
            }
            
            // Perte de point si le dino disparaît sans être cliqué (sauf en mode Chaos)
            if (!isChaosMode) {
                updateScore(-1);
            }
            
            setTimeout(() => {
                if (dino.parentNode) {
                    dino.parentNode.removeChild(dino);
                }
            }, 300);
        }
    }, lifeTime);
}

function startSpawning() {
    // Spawn initial
    spawnDino();
    
    // Spawn régulier selon la configuration du mode
    spawnInterval = setInterval(() => {
        if (gameActive && activeDinos.length < gameConfig.maxDinos) {
            spawnDino();
        }
    }, gameConfig.spawnRate + Math.random() * gameConfig.spawnVariation);
}

function stopSpawning() {
    if (spawnInterval) {
        clearInterval(spawnInterval);
        spawnInterval = null;
    }
    
    // Supprime tous les dinosaures actifs
    activeDinos.forEach(dino => {
        if (dino.parentNode) {
            dino.parentNode.removeChild(dino);
        }
    });
    activeDinos = [];
}

function endGame() {
    gameActive = false;
    stopSpawning();
    
    if (gameTimer) {
        clearInterval(gameTimer);
        gameTimer = null;
    }
    
    // Arrêter la musique
    if (window.audioManager) {
        window.audioManager.stopGameMusic();
    }
    
    // Sauvegarde le score
    const updatedScores = saveScore(score);
    const isNewRecord = updatedScores.length > 0 && updatedScores[0].score === score;
    
    // Affiche la modal de fin de jeu
    showEndGameModal(isNewRecord);
}

function showEndGameModal(isNewRecord) {
    // Crée la modal de fin de jeu
    let modal = document.getElementById('endgame-modal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'endgame-modal';
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(0, 0, 0, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 10001;
            opacity: 0;
            transition: opacity 0.3s ease;
        `;
        document.body.appendChild(modal);
    }
    
    modal.innerHTML = `
        <div style="
            background: linear-gradient(135deg, #ffffff 0%, #f0f0f0 100%);
            border: 4px solid #333;
            border-radius: 20px;
            padding: 40px;
            max-width: 600px;
            width: 90%;
            text-align: center;
            box-shadow: 0 15px 0 #333, 0 20px 40px rgba(0, 0, 0, 0.6);
        ">
            <h2 style="
                font-size: 3em;
                margin-bottom: 20px;
                background: linear-gradient(90deg, #ff0055, #ff9900, #ffee00, #33dd66, #00aaff, #8855ff, #ff0055);
                background-size: 200% 200%;
                -webkit-background-clip: text;
                background-clip: text;
                -webkit-text-fill-color: transparent;
                -webkit-text-stroke: 2px #333;
                animation: gradientShift 2s ease infinite;
            ">${isNewRecord ? '🎉 NOUVEAU RECORD ! 🎉' : '⏰ TEMPS ÉCOULÉ !'}</h2>
            
            <div style="
                font-size: 2.5em;
                font-weight: bold;
                color: #333;
                margin: 30px 0;
                background: linear-gradient(90deg, #ff0055, #ff9900, #ffee00, #33dd66, #00aaff, #8855ff, #ff0055);
                background-size: 200% 200%;
                -webkit-background-clip: text;
                background-clip: text;
                -webkit-text-fill-color: transparent;
                -webkit-text-stroke: 1px #333;
                animation: gradientShift 2s ease infinite;
            ">SCORE : ${score} POINTS</div>
            
            <div style="display: flex; gap: 20px; justify-content: center; margin-top: 40px;">
                <button onclick="restartGame(); closeEndGameModal();" style="
                    background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%);
                    border: none;
                    border-radius: 15px;
                    padding: 15px 30px;
                    font-size: 1.5em;
                    font-weight: bold;
                    color: white;
                    cursor: pointer;
                    box-shadow: 0 6px 0 #2e7d32, 0 8px 20px rgba(0, 0, 0, 0.3);
                    transition: transform 0.1s ease;
                    -webkit-text-stroke: 1px rgba(0,0,0,0.3);
                " onmousedown="this.style.transform='translateY(3px)'; this.style.boxShadow='0 3px 0 #2e7d32, 0 5px 15px rgba(0, 0, 0, 0.3)';"
                   onmouseup="this.style.transform='translateY(0)'; this.style.boxShadow='0 6px 0 #2e7d32, 0 8px 20px rgba(0, 0, 0, 0.3)';"
                   onmouseleave="this.style.transform='translateY(0)'; this.style.boxShadow='0 6px 0 #2e7d32, 0 8px 20px rgba(0, 0, 0, 0.3)';">
                    🔄 REJOUER
                </button>
                
                <button onclick="showHighScores(); closeEndGameModal();" style="
                    background: linear-gradient(135deg, #2196F3 0%, #1976D2 100%);
                    border: none;
                    border-radius: 15px;
                    padding: 15px 30px;
                    font-size: 1.5em;
                    font-weight: bold;
                    color: white;
                    cursor: pointer;
                    box-shadow: 0 6px 0 #1565C0, 0 8px 20px rgba(0, 0, 0, 0.3);
                    transition: transform 0.1s ease;
                    -webkit-text-stroke: 1px rgba(0,0,0,0.3);
                " onmousedown="this.style.transform='translateY(3px)'; this.style.boxShadow='0 3px 0 #1565C0, 0 5px 15px rgba(0, 0, 0, 0.3)';"
                   onmouseup="this.style.transform='translateY(0)'; this.style.boxShadow='0 6px 0 #1565C0, 0 8px 20px rgba(0, 0, 0, 0.3)';"
                   onmouseleave="this.style.transform='translateY(0)'; this.style.boxShadow='0 6px 0 #1565C0, 0 8px 20px rgba(0, 0, 0, 0.3)';">
                    🏆 SCORES
                </button>
                
                <button onclick="window.location.href='mode-de-jeu.html';" style="
                    background: linear-gradient(135deg, #ff9800 0%, #f57c00 100%);
                    border: none;
                    border-radius: 15px;
                    padding: 15px 30px;
                    font-size: 1.5em;
                    font-weight: bold;
                    color: white;
                    cursor: pointer;
                    box-shadow: 0 6px 0 #ef6c00, 0 8px 20px rgba(0, 0, 0, 0.3);
                    transition: transform 0.1s ease;
                    -webkit-text-stroke: 1px rgba(0,0,0,0.3);
                " onmousedown="this.style.transform='translateY(3px)'; this.style.boxShadow='0 3px 0 #ef6c00, 0 5px 15px rgba(0, 0, 0, 0.3)';"
                   onmouseup="this.style.transform='translateY(0)'; this.style.boxShadow='0 6px 0 #ef6c00, 0 8px 20px rgba(0, 0, 0, 0.3)';"
                   onmouseleave="this.style.transform='translateY(0)'; this.style.boxShadow='0 6px 0 #ef6c00, 0 8px 20px rgba(0, 0, 0, 0.3)';">
                    🎮 MODES
                </button>
            </div>
        </div>
    `;
    
    // Affiche la modal avec animation
    modal.style.display = 'flex';
    setTimeout(() => {
        modal.style.opacity = '1';
    }, 10);
}

function closeEndGameModal() {
    const modal = document.getElementById('endgame-modal');
    if (modal) {
        modal.style.opacity = '0';
        setTimeout(() => {
            modal.style.display = 'none';
        }, 300);
    }
}

function restartGame() {
    score = 0;
    gameTimeLeft = isHardcoreMode ? 30 : (isChaosMode ? 45 : 60);
    scoreElement.textContent = score;
    gameActive = true;
    
    // Sync score uniquement
    window.score = score;
    
    startSpawning();
    startGameTimer();
    
    // Redémarrer la musique
    if (window.audioManager) {
        const currentMode = isHardcoreMode ? "HARDCORE" : (isChaosMode ? "CHAOS" : "CHASSE");
        window.audioManager.startGameMusic(currentMode);
    }
}

// Fonctions globales (accessibles depuis le HTML)
window.closeScoresModal = closeScoresModal;
window.showHighScores = showHighScores;
window.clearAllScores = clearAllScores;
window.closeEndGameModal = closeEndGameModal;
window.restartGame = restartGame;

// Modification du titre selon le mode
if (isHardcoreMode) {
    document.title = 'LSD Dino - Mode Chasse HARDCORE';
    const titleElement = document.querySelector('.titre-LSD');
    if (titleElement) {
        titleElement.innerHTML = '<span class="dino-title-icon">💀</span> MODE CHASSE HARDCORE <span class="dino-title-icon">💥</span>';
        titleElement.style.color = '#ff0000';
        titleElement.style.textShadow = '0 0 20px rgba(255, 0, 0, 0.8)';
    }
    
    // Modification du background pour le mode hardcore
    document.body.style.background = 'linear-gradient(90deg, #ff0000, #ff4400, #ff0055, #aa0000, #ff0000, #880000, #ff0000)';
    document.body.style.animation = 'gradientShift 1s ease infinite'; // Plus rapide
} else if (isChaosMode) {
    document.title = 'LSD Dino - Mode Chasse CHAOS';
    const titleElement = document.querySelector('.titre-LSD');
    if (titleElement) {
        titleElement.innerHTML = '<span class="dino-title-icon">🌪️</span> MODE CHASSE CHAOS <span class="dino-title-icon">💫</span>';
        titleElement.style.background = 'linear-gradient(90deg, #ff9800, #ffeb3b, #4caf50, #2196f3, #9c27b0, #ff9800)';
        titleElement.style.backgroundSize = '200% 200%';
        titleElement.style.webkitBackgroundClip = 'text';
        titleElement.style.backgroundClip = 'text';
        titleElement.style.webkitTextFillColor = 'transparent';
        titleElement.style.animation = 'gradientShift 0.5s ease infinite';
    }
    
    // Modification du background pour le mode chaos
    document.body.style.background = 'linear-gradient(90deg, #ff9800, #ffeb3b, #4caf50, #2196f3, #9c27b0, #e91e63, #ff9800)';
    document.body.style.animation = 'gradientShift 0.3s ease infinite'; // Ultra rapide
}

// Sauvegarde des scores avec distinction du mode
const originalSaveScore = saveScore;
saveScore = function(playerScore) {
    const storageKey = isHardcoreMode ? 'lsd-dino-hunt-hardcore-scores' : 
                      (isChaosMode ? 'lsd-dino-hunt-chaos-scores' : 'lsd-dino-hunt-scores');
    const scores = localStorage.getItem(storageKey) ? JSON.parse(localStorage.getItem(storageKey)) : [];
    
    const now = new Date();
    const scoreEntry = {
        score: playerScore,
        date: now.toLocaleDateString('fr-FR'),
        time: now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
        mode: isHardcoreMode ? 'HARDCORE' : (isChaosMode ? 'CHAOS' : 'NORMAL')
    };
    
    scores.push(scoreEntry);
    scores.sort((a, b) => b.score - a.score);
    scores.splice(10);
    
    localStorage.setItem(storageKey, JSON.stringify(scores));
    return scores;
};

// Modification de la fonction getHighScores pour tous les modes
const originalGetHighScores = getHighScores;
getHighScores = function() {
    const storageKey = isHardcoreMode ? 'lsd-dino-hunt-hardcore-scores' : 
                      (isChaosMode ? 'lsd-dino-hunt-chaos-scores' : 'lsd-dino-hunt-scores');
    const scores = localStorage.getItem(storageKey);
    return scores ? JSON.parse(scores) : [];
};

// Démarre le jeu après le timer de 3 secondes
setTimeout(() => {
    gameActive = true;
    startSpawning();
    startGameTimer();
    
    // Démarrer la musique selon le mode
    if (window.audioManager) {
        const currentMode = isHardcoreMode ? "HARDCORE" : (isChaosMode ? "CHAOS" : "CHASSE");
        window.audioManager.startGameMusic(currentMode);
    }
}, 3000);
