/**
 * Module de communication série avec Arduino pour LSD-Dino
 * Utilise l'API Web Serial pour envoyer les données du jeu à l'Arduino
 */

class ArduinoSerial {
    constructor() {
        this.port = null;
        this.writer = null;
        this.reader = null;
        this.connected = false;
        this.lastScore = 0;
        this.lastTime = 60;
        this.lastMode = "CLASSIQUE";
        this.lastActive = false;
        this.autoReconnectAttempts = 0;
        this.maxReconnectAttempts = 3;
    }

    // Vérifier si l'API Web Serial est supportée
    isSupported() {
        return 'serial' in navigator;
    }

    // Connecter à l'Arduino
    async connect() {
        if (!this.isSupported()) {
            throw new Error('Web Serial API non supportée. Utilisez Chrome/Edge version récente.');
        }

        try {
            // Demander à l'utilisateur de sélectionner le port série
            this.port = await navigator.serial.requestPort();
            
            // Ouvrir la connexion série (9600 baud comme dans l'Arduino)
            await this.port.open({ baudRate: 9600 });
            
            // Créer les streams de lecture/écriture
            this.writer = this.port.writable.getWriter();
            this.reader = this.port.readable.getReader();
            
            this.connected = true;
            console.log('Arduino connecté avec succès !');
            
            // Sauvegarder l'état de connexion
            localStorage.setItem('arduino-connected', 'true');
            localStorage.setItem('arduino-connect-time', Date.now().toString());
            
            // Envoyer un message de test
            await this.sendData(0, 60, "CLASSIQUE", false);
            
            return true;
        } catch (error) {
            console.error('Erreur de connexion Arduino:', error);
            throw error;
        }
    }

    // Déconnecter l'Arduino
    async disconnect() {
        if (this.writer) {
            this.writer.releaseLock();
        }
        if (this.reader) {
            this.reader.releaseLock();
        }
        if (this.port) {
            await this.port.close();
        }
        
        this.connected = false;
        this.port = null;
        this.writer = null;
        this.reader = null;
        
        // Supprimer l'état de connexion sauvegardé
        localStorage.removeItem('arduino-connected');
        localStorage.removeItem('arduino-connect-time');
        
        console.log('Arduino déconnecté');
    }

    // Envoyer des données à l'Arduino
    async sendData(score, timeRemaining, gameMode, gameActive) {
        if (!this.connected || !this.writer) {
            console.warn('Arduino non connecté');
            return false;
        }

        try {
            // Format: "SCORE:123,TIME:45,MODE:CLASSIQUE,ACTIVE:1"
            const data = `SCORE:${score},TIME:${timeRemaining},MODE:${gameMode},ACTIVE:${gameActive ? 1 : 0}\n`;
            
            // Convertir en bytes et envoyer
            const encoder = new TextEncoder();
            await this.writer.write(encoder.encode(data));
            
            // Sauvegarder les dernières valeurs
            this.lastScore = score;
            this.lastTime = timeRemaining;
            this.lastMode = gameMode;
            this.lastActive = gameActive;
            
            console.log('Données envoyées à Arduino:', data.trim());
            return true;
        } catch (error) {
            console.error('Erreur envoi données:', error);
            return false;
        }
    }

    // Envoyer seulement si les données ont changé (optimisation)
    async sendDataIfChanged(score, timeRemaining, gameMode, gameActive) {
        if (score !== this.lastScore || 
            timeRemaining !== this.lastTime || 
            gameMode !== this.lastMode || 
            gameActive !== this.lastActive) {
            
            return await this.sendData(score, timeRemaining, gameMode, gameActive);
        }
        return true;
    }

    // Lire les données de l'Arduino (optionnel)
    async readData() {
        if (!this.connected || !this.reader) {
            return null;
        }

        try {
            const { value, done } = await this.reader.read();
            if (done) {
                return null;
            }
            
            const decoder = new TextDecoder();
            return decoder.decode(value);
        } catch (error) {
            console.error('Erreur lecture Arduino:', error);
            return null;
        }
    }

    // Obtenir le statut de connexion
    isConnected() {
        return this.connected;
    }

    // Tentative de reconnexion automatique
    async tryAutoReconnect() {
        if (this.autoReconnectAttempts >= this.maxReconnectAttempts) {
            console.log('Nombre maximum de tentatives de reconnexion atteint');
            return false;
        }

        // Vérifier si on était connecté récemment (moins de 5 minutes)
        const lastConnectTime = localStorage.getItem('arduino-connect-time');
        const wasConnected = localStorage.getItem('arduino-connected') === 'true';
        
        if (!wasConnected || !lastConnectTime) {
            return false;
        }

        const timeSinceConnect = Date.now() - parseInt(lastConnectTime);
        const fiveMinutes = 5 * 60 * 1000;
        
        if (timeSinceConnect > fiveMinutes) {
            console.log('Connexion trop ancienne, pas de reconnexion automatique');
            localStorage.removeItem('arduino-connected');
            localStorage.removeItem('arduino-connect-time');
            return false;
        }

        try {
            console.log(`Tentative de reconnexion automatique (${this.autoReconnectAttempts + 1}/${this.maxReconnectAttempts})...`);
            this.autoReconnectAttempts++;
            
            // Essayer de récupérer le port depuis les ports autorisés
            const ports = await navigator.serial.getPorts();
            if (ports.length > 0) {
                this.port = ports[0]; // Prendre le premier port autorisé
                await this.port.open({ baudRate: 9600 });
                
                this.writer = this.port.writable.getWriter();
                this.reader = this.port.readable.getReader();
                this.connected = true;
                
                console.log('Reconnexion automatique réussie !');
                await this.sendData(0, 60, "RECONNECTE", false);
                
                return true;
            }
        } catch (error) {
            console.log('Échec de la reconnexion automatique:', error.message);
        }
        
        return false;
    }

    // Réinitialiser le compteur de reconnexion
    resetReconnectAttempts() {
        this.autoReconnectAttempts = 0;
    }
}

// Instance globale
const arduinoSerial = new ArduinoSerial();

// Interface utilisateur pour la connexion Arduino
function createArduinoUI() {
    // Vérifier le support
    if (!arduinoSerial.isSupported()) {
        console.warn('Web Serial API non supportée');
        return;
    }

    // Créer le bouton de connexion
    const connectBtn = document.createElement('button');
    connectBtn.id = 'arduino-connect-btn';
    connectBtn.textContent = '🔌 Connecter Arduino';
    connectBtn.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%);
        color: white;
        border: none;
        padding: 12px 20px;
        border-radius: 8px;
        cursor: pointer;
        font-weight: bold;
        z-index: 1000;
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        transition: all 0.3s ease;
    `;

    // Créer un indicateur de statut
    const statusIndicator = document.createElement('div');
    statusIndicator.id = 'arduino-status';
    statusIndicator.style.cssText = `
        position: fixed;
        bottom: 80px;
        right: 20px;
        background: rgba(0,0,0,0.8);
        color: white;
        padding: 8px 12px;
        border-radius: 5px;
        font-size: 12px;
        z-index: 999;
        display: none;
        transition: all 0.3s ease;
    `;
    document.body.appendChild(statusIndicator);

    // Gestionnaire de clic
    connectBtn.addEventListener('click', async () => {
        if (!arduinoSerial.isConnected()) {
            try {
                connectBtn.textContent = '🔄 Connexion...';
                connectBtn.disabled = true;
                
                await arduinoSerial.connect();
                
                // Réinitialiser le compteur de reconnexion après une connexion manuelle réussie
                arduinoSerial.resetReconnectAttempts();
                
                connectBtn.textContent = '✅ Arduino connecté';
                connectBtn.style.background = 'linear-gradient(135deg, #2196F3 0%, #1976D2 100%)';
                
                // Changer le bouton en déconnexion après 2 secondes
                setTimeout(() => {
                    connectBtn.textContent = '🔌 Déconnecter';
                    connectBtn.disabled = false;
                }, 2000);
                
            } catch (error) {
                connectBtn.textContent = '❌ Erreur connexion';
                connectBtn.style.background = 'linear-gradient(135deg, #f44336 0%, #d32f2f 100%)';
                connectBtn.disabled = false;
                
                setTimeout(() => {
                    connectBtn.textContent = '🔌 Connecter Arduino';
                    connectBtn.style.background = 'linear-gradient(135deg, #4CAF50 0%, #45a049 100%)';
                }, 3000);
                
                alert('Erreur de connexion Arduino:\n' + error.message);
            }
        } else {
            // Déconnecter
            await arduinoSerial.disconnect();
            connectBtn.textContent = '🔌 Connecter Arduino';
            connectBtn.style.background = 'linear-gradient(135deg, #4CAF50 0%, #45a049 100%)';
        }
    });

    // Ajouter le bouton à la page
    document.body.appendChild(connectBtn);
    
    // Créer un bouton de test (seulement si connecté)
    const testBtn = document.createElement('button');
    testBtn.id = 'arduino-test-btn';
    testBtn.textContent = '🧪 Test Actif';
    testBtn.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 200px;
        background: linear-gradient(135deg, #ff9800 0%, #f57c00 100%);
        color: white;
        border: none;
        padding: 8px 15px;
        border-radius: 5px;
        cursor: pointer;
        font-weight: bold;
        z-index: 1000;
        font-size: 12px;
        display: none;
    `;
    
    testBtn.addEventListener('click', () => {
        if (arduinoSerial.isConnected()) {
            // Envoyer des données de test avec jeu actif
            arduinoSerial.sendData(42, 30, "TEST", true);
            console.log('🧪 Test envoyé: Score=42, Time=30, Mode=TEST, Active=true');
        }
    });
    
    document.body.appendChild(testBtn);
    
    // Afficher/masquer le bouton de test selon la connexion
    setInterval(() => {
        testBtn.style.display = arduinoSerial.isConnected() ? 'block' : 'none';
    }, 1000);
}

// Fonction pour intégrer avec le jeu LSD-Dino
function integrateWithGame() {
    // Envoyer les données toutes les secondes
    setInterval(() => {
        if (arduinoSerial.isConnected()) {
            // Récupérer les variables du jeu selon la page
            const gameData = getGameData();
            
            // Debug : afficher les données dans la console
            console.log('🎮 Données jeu:', {
                page: window.location.pathname,
                score: gameData.score,
                time: gameData.time,
                mode: gameData.mode,
                active: gameData.active,
                windowVars: {
                    gameActive: window.gameActive,
                    gameTimeLeft: window.gameTimeLeft,
                    score: window.score
                }
            });
            
            arduinoSerial.sendDataIfChanged(
                gameData.score,
                gameData.time,
                gameData.mode,
                gameData.active
            );
        }
    }, 1000);
}

// Fonction pour détecter et récupérer les données selon le mode de jeu
function getGameData() {
    const currentPage = window.location.pathname.toLowerCase();
    const urlParams = new URLSearchParams(window.location.search);
    
    let gameData = {
        score: 0,
        time: 60,
        mode: "MENU",
        active: false
    };
    
    // Mode Classique (LSD-dino.html)
    if (currentPage.includes('lsd-dino.html')) {
        gameData.score = window.score || document.getElementById('score-value')?.textContent || 0;
        gameData.time = window.timeRemaining || window.gameTimeLeft || 60;
        gameData.mode = "CLASSIQUE";
        // Détecter si le jeu est actif par plusieurs moyens
        gameData.active = window.gameActive || window.gameStarted || 
                         document.getElementById('timer-overlay')?.style.display === 'none' ||
                         (gameData.time > 0 && gameData.time < 60);
    }
    
    // Jeu de symétrie (LSD dino.html avec espace)
    else if (currentPage.includes('lsd dino.html')) {
        gameData.score = window.score || document.getElementById('score')?.textContent || 0;
        gameData.time = 60; // Pas de timer dans ce jeu
        gameData.mode = "SYMETRIE";
        gameData.active = true; // Toujours actif
    }
    
    // Mode Chasse principal (chasse-dino.html) - FOCUS PRINCIPAL
    else if (currentPage.includes('chasse-dino.html')) {
        const mode = urlParams.get('mode');
        
        // Récupérer les variables directement depuis le script chasse-event.js
        gameData.score = window.score || 0;
        gameData.time = window.gameTimeLeft || 60;
        gameData.active = window.gameActive || false;
        
        // Déterminer le mode
        if (mode === 'hardcore' || window.isHardcoreMode) {
            gameData.mode = "HARDCORE";
        } else if (mode === 'chaos' || window.isChaosMode) {
            gameData.mode = "CHAOS";
        } else {
            gameData.mode = "CHASSE";
        }
        
        // Debug spécifique pour le mode chasse
        console.log('🎯 Mode Chasse détecté:', {
            url: window.location.href,
            scoreWindow: window.score,
            timeWindow: window.gameTimeLeft,
            activeWindow: window.gameActive,
            isHardcore: window.isHardcoreMode,
            isChaos: window.isChaosMode
        });
    }
    
    // Pages de menu
    else if (currentPage.includes('index') || currentPage.includes('mode-de-jeu')) {
        gameData.mode = "MENU";
        gameData.active = false;
        gameData.score = 0;
        gameData.time = 0;
    }
    
    // Convertir en nombres si nécessaire
    if (typeof gameData.score === 'string') {
        gameData.score = parseInt(gameData.score) || 0;
    }
    if (typeof gameData.time === 'string') {
        gameData.time = parseInt(gameData.time) || 0;
    }
    
    return gameData;
}

// Initialisation automatique
document.addEventListener('DOMContentLoaded', async () => {
    createArduinoUI();
    
    // Essayer la reconnexion automatique
    const reconnected = await arduinoSerial.tryAutoReconnect();
    if (reconnected) {
        // Mettre à jour l'interface utilisateur
        const connectBtn = document.getElementById('arduino-connect-btn');
        const statusIndicator = document.getElementById('arduino-status');
        
        if (connectBtn) {
            connectBtn.textContent = '✅ Arduino reconnecté';
            connectBtn.style.background = 'linear-gradient(135deg, #2196F3 0%, #1976D2 100%)';
            
            setTimeout(() => {
                connectBtn.textContent = '🔌 Déconnecter';
            }, 2000);
        }
        
        if (statusIndicator) {
            statusIndicator.textContent = '🔄 Reconnecté automatiquement';
            statusIndicator.style.display = 'block';
            statusIndicator.style.background = 'rgba(76, 175, 80, 0.9)';
            
            setTimeout(() => {
                statusIndicator.style.display = 'none';
            }, 3000);
        }
    }
    
    // Attendre un peu que le jeu se charge
    setTimeout(integrateWithGame, 2000);
});

// Export pour utilisation externe
window.arduinoSerial = arduinoSerial;
