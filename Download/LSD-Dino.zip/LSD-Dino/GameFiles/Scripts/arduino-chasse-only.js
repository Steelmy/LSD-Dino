/*
 * Script Arduino spécifique pour le mode Chasse uniquement
 * Se connecte directement aux variables de chasse-event.js
 */

// Attendre que les variables du jeu soient disponibles
function waitForGameVariables() {
    return new Promise((resolve) => {
        const checkVariables = () => {
            // Les variables sont déclarées avec 'let' dans chasse-event.js
            // On doit les rendre globales ou les détecter autrement
            console.log('🔍 Vérification variables:', {
                score: typeof score !== 'undefined' ? score : 'undefined',
                gameActive: typeof gameActive !== 'undefined' ? gameActive : 'undefined', 
                gameTimeLeft: typeof gameTimeLeft !== 'undefined' ? gameTimeLeft : 'undefined',
                windowScore: window.score,
                windowGameActive: window.gameActive
            });
            
            // Essayer de détecter les éléments DOM du jeu
            const scoreElement = document.getElementById('score-value');
            const timerOverlay = document.getElementById('timer-overlay');
            
            if (scoreElement) {
                console.log('✅ Éléments de jeu détectés');
                resolve();
            } else {
                console.log('⏳ Attente des éléments de jeu...');
                setTimeout(checkVariables, 500);
            }
        };
        checkVariables();
    });
}

// Fonction optimisée pour envoyer uniquement score et mode
async function sendGameDataToArduino() {
    if (!window.arduinoSerial || !window.arduinoSerial.isConnected()) {
        return;
    }

    // Score depuis l'élément DOM (plus fiable)
    const scoreElement = document.getElementById('score-value');
    const currentScore = scoreElement ? parseInt(scoreElement.textContent) || 0 : 0;
    
    // Déterminer le mode depuis l'URL
    const urlParams = new URLSearchParams(window.location.search);
    const mode = urlParams.get('mode');
    let currentMode = "CHASSE";
    if (mode === 'hardcore') {
        currentMode = "HARDCORE";
    } else if (mode === 'chaos') {
        currentMode = "CHAOS";
    }

    // Détecter si le jeu est actif (simplifié)
    let currentActive = false;
    
    // Méthode simple: Timer overlay caché = jeu actif
    const timerOverlay = document.getElementById('timer-overlay');
    if (timerOverlay && timerOverlay.style.display === 'none') {
        currentActive = true;
    }
    
    // Ou si on a un score > 0
    if (currentScore > 0) {
        currentActive = true;
    }

    // Debug simplifié
    console.log('📤 Arduino:', {
        score: currentScore,
        mode: currentMode,
        active: currentActive
    });

    // Envoyer à l'Arduino (temps fixe à 0 car non utilisé)
    await window.arduinoSerial.sendData(currentScore, 0, currentMode, currentActive);
}

// Initialisation spécifique pour le mode chasse
async function initArduinoForChasse() {
    console.log('🎯 Initialisation Arduino pour mode Chasse');
    
    // Attendre que les variables soient disponibles
    await waitForGameVariables();
    
    // Envoyer les données toutes les secondes
    setInterval(sendGameDataToArduino, 1000);
    
    console.log('✅ Arduino connecté au mode Chasse');
}

// Démarrer quand la page est chargée
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initArduinoForChasse);
} else {
    initArduinoForChasse();
}
