/*
 * Solution Audio Simple - Bouton de démarrage visible
 * Approche directe et efficace
 */

class SimpleAudioManager {
    constructor() {
        this.currentAudio = null;
        this.isEnabled = false;
        this.volume = 0.5;
        this.pendingMode = null;
        
        this.tracks = {
            CHASSE: '../audio/' + encodeURIComponent('lovely sad. by 24gh.mp3'),
            HARDCORE: '../audio/' + encodeURIComponent('ТРИ ПОЛОСКИ  KOLM TRIIPU  THREE STRIPES.mp3'),
            CHAOS: '../audio/' + encodeURIComponent('Mission Impossible Fallout Theme (Cover).mp3'),
            CLASSIQUE: '../audio/' + encodeURIComponent('Wii Party Soundtrack - Main Menu Music.mp3')
        };
        
        this.createStartButton();
    }
    
    createStartButton() {
        // Créer un bouton de démarrage en bas à gauche
        const startBtn = document.createElement('button');
        startBtn.id = 'audio-start-btn';
        startBtn.innerHTML = '🎵 ACTIVER MUSIQUE';
        startBtn.style.cssText = `
            position: fixed;
            bottom: 20px;
            left: 20px;
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%);
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
            font-size: 14px;
            z-index: 10000;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            transition: all 0.3s ease;
            animation: pulse 2s infinite;
        `;
        
        // Animation CSS
        const style = document.createElement('style');
        style.textContent = `
            @keyframes pulse {
                0% { transform: scale(1); }
                50% { transform: scale(1.05); }
                100% { transform: scale(1); }
            }
            #audio-start-btn:hover {
                transform: scale(1.1) !important;
                box-shadow: 0 6px 20px rgba(0,0,0,0.4) !important;
            }
        `;
        document.head.appendChild(style);
        
        startBtn.addEventListener('click', () => {
            this.enableAudio();
            startBtn.remove();
        });
        
        document.body.appendChild(startBtn);
        
        // Changer le texte après 8 secondes si pas cliqué
        setTimeout(() => {
            if (document.getElementById('audio-start-btn')) {
                startBtn.innerHTML = '🎵 MUSIQUE';
                startBtn.style.opacity = '0.8';
            }
        }, 8000);
    }
    
    enableAudio() {
        this.isEnabled = true;
        console.log('🎵 Audio activé par l\'utilisateur');
        
        // Jouer la musique en attente
        if (this.pendingMode) {
            this.playTrack(this.pendingMode);
            this.pendingMode = null;
        }
        
        // Message de confirmation
        this.showMessage('🎵 Musique activée !');
    }
    
    
    playTrack(mode) {
        if (!this.isEnabled) {
            console.log(`🎵 Audio non activé, mise en attente: ${mode}`);
            this.pendingMode = mode;
            return;
        }
        
        const trackSrc = this.tracks[mode];
        if (!trackSrc) {
            console.log(`🎵 Pas de musique pour ${mode}`);
            return;
        }
        
        // Arrêter la musique actuelle
        if (this.currentAudio) {
            this.currentAudio.pause();
        }
        
        // Créer et jouer la nouvelle piste
        this.currentAudio = new Audio(trackSrc);
        this.currentAudio.loop = true;
        this.currentAudio.volume = this.volume;
        
        this.currentAudio.play().then(() => {
            console.log(`🎵 Lecture: ${mode}`);
            this.showMessage(`♪ ${mode}`);
        }).catch(error => {
            console.warn(`🎵 Erreur: ${error.name}`);
            this.showMessage(`❌ Erreur audio ${mode}`);
        });
    }
    
    stopTrack() {
        if (this.currentAudio) {
            this.currentAudio.pause();
            this.currentAudio = null;
        }
    }
    
    showMessage(text) {
        const msg = document.createElement('div');
        msg.textContent = text;
        msg.style.cssText = `
            position: fixed;
            bottom: 20px;
            left: 200px;
            background: rgba(0,0,0,0.8);
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
            z-index: 1001;
            font-size: 14px;
        `;
        
        document.body.appendChild(msg);
        setTimeout(() => {
            msg.remove();
        }, 3000);
    }
    
    // API publique
    startGameMusic(mode) {
        console.log(`🎵 Demande de musique: ${mode}`);
        this.playTrack(mode);
    }
    
    stopGameMusic() {
        this.stopTrack();
    }
}

// Instance globale
const simpleAudioManager = new SimpleAudioManager();
window.audioManager = simpleAudioManager;

console.log('🎵 SimpleAudioManager chargé');
