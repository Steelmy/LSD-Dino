// ===== TIMER QUI MET TOUTE LA PAGE EN PAUSE =====
let countdown = 3;
const overlay = document.getElementById('timer-overlay');
const countdownElement = document.getElementById('countdown');
let isPaused = true; // La page est en pause au démarrage

// Fonction qui bloque TOUS les événements
const blockEverything = (e) => {
    if (isPaused) {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        return false;
    }
};

// Liste complète de tous les événements à bloquer
const allEvents = [
    'click', 'dblclick', 'mousedown', 'mouseup', 'mousemove', 'mouseover', 'mouseout', 'mouseenter', 'mouseleave',
    'keydown', 'keyup', 'keypress',
    'touchstart', 'touchend', 'touchmove', 'touchcancel',
    'pointerdown', 'pointerup', 'pointermove', 'pointerover', 'pointerout',
    'wheel', 'scroll',
    'focus', 'blur',
    'input', 'change', 'submit'
];

// Bloque tous les événements sur le document entier
allEvents.forEach(eventType => {
    window.addEventListener(eventType, blockEverything, { capture: true, passive: false });
});

// Bloque aussi les animations CSS et JavaScript
const styleBlock = document.createElement('style');
styleBlock.id = 'pause-style';
styleBlock.textContent = `
    *, *::before, *::after {
        animation-play-state: paused !important;
        transition: none !important;
    }
    #timer-overlay, #timer-overlay * {
        animation-play-state: running !important;
        transition: opacity 0.5s ease !important;
    }
`;
document.head.appendChild(styleBlock);

// Compte à rebours
const timerInterval = setInterval(() => {
    countdown--;
    countdownElement.textContent = countdown;
    
    if (countdown <= 0) {
        clearInterval(timerInterval);
        
        // DÉBLOQUE TOUT
        isPaused = false;
        
        // Retire le blocage des animations
        const pauseStyle = document.getElementById('pause-style');
        if (pauseStyle) {
            pauseStyle.remove();
        }
        
        // Retire tous les event listeners
        allEvents.forEach(eventType => {
            window.removeEventListener(eventType, blockEverything, { capture: true });
        });
        
        // Masque l'overlay
        overlay.style.opacity = '0';
        setTimeout(() => {
            overlay.style.display = 'none';
        }, 500);
    }
}, 1000);
