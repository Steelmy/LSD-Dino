# Musiques LSD-Dino

## Fichiers audio requis :

### Mode Chasse Normal
- **Fichier :** `chasse-music.mp3`
- **Style :** Musique d'action/aventure
- **Durée :** 2-3 minutes (en boucle)
- **Ambiance :** Énergique, motivante

### Mode Hardcore
- **Fichier :** `hardcore-music.mp3`
- **Style :** Musique intense/électronique
- **Durée :** 1-2 minutes (en boucle)
- **Ambiance :** Stressante, rapide, intense

### Mode Chaos
- **Fichier :** `chaos-music.mp3`
- **Style :** Musique chaotique/expérimentale
- **Durée :** 2-3 minutes (en boucle)
- **Ambiance :** Imprévisible, folle

## Sources recommandées :

1. **Musiques libres de droits :**
   - Freesound.org
   - Zapsplat.com
   - YouTube Audio Library

2. **Générateurs de musique IA :**
   - Suno AI
   - Udio
   - Mubert

3. **Formats supportés :**
   - MP3 (recommandé)
   - WAV
   - OGG

## Instructions :

1. Ajoutez vos fichiers audio dans ce dossier
2. Respectez les noms de fichiers exacts
3. Testez le volume et la qualité
4. Optimisez la taille des fichiers (128-192 kbps)
